<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-16 00:10:52
  from 'c055244e02030149c195bb2de9df8275da247708' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f38798c9b9898_49325474',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f38798c9b9898_49325474 (Smarty_Internal_Template $_smarty_tpl) {
?>Required :<br />
<br />
&bull;	S1/S2 Bachelor&rsquo;s or Master&rsquo;s degree minimum in Bahasa Indonesia or related field<br />
&bull;	Excellent standard of English<br />
&bull;	Experience teaching Bahasa Indonesia Studies at Secondary school level<br />
&bull;	Excellent communication skills and a positive and caring approach<br />
&bull;	Respect for diversity; religion, race, and gender<br />
&bull;	Experience with IGCSE, or IBDP curriculum <br />
&bull;	Energy and Passion for Teaching and Learning<br />
&bull;	Willingness to take on an additional extracurricular duty or club<br />
<br />
Please send your CV and a recent photo to hrd@sekolahbogorraya.com We apologize, but only shortlisted candidates will be contacted.<br />
<?php }
}
