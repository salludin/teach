<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-11 17:30:19
  from 'cf7f80ffadf970cc86035a7c2767c19fef1b3b42' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f32d5ab51c454_61035238',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f32d5ab51c454_61035238 (Smarty_Internal_Template $_smarty_tpl) {
?>Mengelola administrasi  siswa dan membantu administrasi guru/karyawan di unit sekolah, menerima telpon masuk, pendaftaran siswa dan melakukan pembukuan keuangan di unit sekolah <?php }
}
