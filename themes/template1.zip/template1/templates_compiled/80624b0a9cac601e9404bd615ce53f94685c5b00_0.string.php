<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-09 01:35:38
  from '80624b0a9cac601e9404bd615ce53f94685c5b00' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f2f52eabc7712_00174968',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2f52eabc7712_00174968 (Smarty_Internal_Template $_smarty_tpl) {
?>Merencanakan, melaksanakan, dan mengevaluasi kegiatan pembelajaran <br />
Melakukan proses administrasi dan  mendokumentasikan seluruh dokumen pembelajaran sesuai dengan ketentuan sekolah<br />
Berkomunikasi dengan orang tua atau wali siswa untuk mengkomunikasikan kemajuan siswa dan menentukan kebutuhan yang menjadi prioritas bagi siswa dalam proses belajar <br />
Melakukan koordinasi dan pertemuan-pertemuan dengan pihak-pihak sesuai kebutuhan dan ketentuan sekolah<br />
<br />
<?php }
}
