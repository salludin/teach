<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-02 11:25:14
  from '9a5b69df5a91356af3fafa2e291c3063e81e24b8' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f26a29a7ef108_27880857',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f26a29a7ef108_27880857 (Smarty_Internal_Template $_smarty_tpl) {
?>Maximal age 30 years old<br />
Minimal D3 or Bachelor Degree (fresh graduate are welcome)<br />
Computer (Microsoft Office) & Internet literate<br />
Familiar with administration, data entry, or database fields<br />
Good verbal & written communication skills (English)<br />
Available to work immediately<br />
Preferably living around West or North of Jakarta<br />
Requirements:<br />
<br />
Strong attention to details, responsible and reliable in handling administrative work<br />
Possesses initiative and ability to work independently with minimal supervision<br />
Must be a creative and self-motivated individual who is also a team player<br />
<br />
Interested applicants may send us a complete resume with recent pictures & photocopy of ID before 31 Oktober 2018 to:<br />
<br />
BINA BANGSA SCHOOL â€“ Kebon Jeruk<br />
Jl. Arjuna Selatan Kav. 87, Kebon Jeruk â€“ Jakarta Barat<br />
<br />
Please state the position code in the email subject (SAO) Only short-listed candidates will be invited to an interview session<?php }
}
