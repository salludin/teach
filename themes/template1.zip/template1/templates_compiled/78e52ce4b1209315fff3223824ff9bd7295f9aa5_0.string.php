<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-13 23:40:59
  from '78e52ce4b1209315fff3223824ff9bd7295f9aa5' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f35cf8b034fa7_93038223',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f35cf8b034fa7_93038223 (Smarty_Internal_Template $_smarty_tpl) {
?>&bull;	Prepare for teaching the subject of Mathematics (unit plan, assessment, project cover sheet, quiz, written test, handouts, assignments, etc)<br />
&bull;	Being able to understand &amp; constantly update the neeeds &amp; development of the students<br />
&bull;	Making analysis and evaluation of learning outcomes of the students<br />
<?php }
}
