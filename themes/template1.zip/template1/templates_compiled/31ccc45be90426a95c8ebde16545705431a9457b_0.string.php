<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-03 05:15:05
  from '31ccc45be90426a95c8ebde16545705431a9457b' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f279d59687fe1_68789084',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f279d59687fe1_68789084 (Smarty_Internal_Template $_smarty_tpl) {
?>Indonesian/expatriate<br />
Male / female age 26 - 45 years old<br />
Good personality<br />
Loves and cares about the world of education <br />
Physically and mentally healthy<br />
Honest, active, responsible and creative<br />
Ability to work individually and in a team<br />
No criminal history<br />
<br />
Bachelor or Master degree holders according to each major<br />
TEFL/TESL certification<br />
Have a previous working experience min. 5 years (preferred)<br />
Proficient in speaking and writing in English<br />
Computer literate (Word, Excel & Power Point)<br />
<br />
Kindly send your resume, Curriculum Vitae and latest photograph latest by May 31st, 2019 to this email address: recruitment@montesiennaschool.com	<br />
<br />
Only shortlisted candidates will be notified.<br />
<?php }
}
