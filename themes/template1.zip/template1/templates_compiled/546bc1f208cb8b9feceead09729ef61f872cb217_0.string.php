<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-02 11:41:00
  from '546bc1f208cb8b9feceead09729ef61f872cb217' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f26a64c12b2c3_32095147',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f26a64c12b2c3_32095147 (Smarty_Internal_Template $_smarty_tpl) {
?>Chandra Kumala School is inclusive school that promotes tolerance and team-work. Focusing on individuals strengths and weaknesses, we help discover and harness potential. Recognising the innate gifts in all our students, we provide individuals with a curriculum tailored to challenge and develop their intellectual, emotional, and social intelligence. <?php }
}
