<?php
/* Smarty version 3.1.34-dev-7, created on 2020-07-29 23:59:03
  from '44b1860e6e6d886dfcd48fbda614581b05b01b76' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f220d47887653_19100614',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f220d47887653_19100614 (Smarty_Internal_Template $_smarty_tpl) {
?>Having experience in sales area<br />
Having experience in Education industry<br />
Able to market our products and services via telephone<br />
Able to work in a team as well as independently<br />
Multi-tasking and able to work under pressure with an objective to achieve the given target<br />
Have a strong customer service communication skill<br />
Able to operate Ms Word & Ms Excel<br />
Willing to be placed in Cibubur<?php }
}
