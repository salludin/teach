<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-05 04:59:26
  from 'bf47c1de14d7fa7dc6bd893a97080e8c20c2d55f' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f2a3cae5bbe08_68055790',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2a3cae5bbe08_68055790 (Smarty_Internal_Template $_smarty_tpl) {
?>Merealisasikan kebutuhan pembuatan program dan aplikasi baru yang dibutuhkan sekolah<br />
Mengembangkan aplikasi dan program berbasis Android, iOS, dan Windows Store<?php }
}
