<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-01 15:42:24
  from '8da4a59408d3bb11da3dce7ae23bf6f26ed19352' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f258d60b4e786_77574861',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f258d60b4e786_77574861 (Smarty_Internal_Template $_smarty_tpl) {
?>&bull;	Prepare for teaching the subject of Physical Education <br />
&bull;	Being able to understand &amp; constantly update the neeeds &amp; development of the students<br />
&bull;	Making analysis and evaluation of learning outcomes of the students<br />
<?php }
}
