<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-05 08:56:07
  from '0d358ca30658d11e0458ac63fe952a6e5095f4bd' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f2a74271e2f52_18987169',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2a74271e2f52_18987169 (Smarty_Internal_Template $_smarty_tpl) {
?>Leading Teachers and Staff to increase the quality and reach Schools Vission<?php }
}
