<?php
/* Smarty version 3.1.34-dev-7, created on 2020-07-30 18:12:42
  from '95947c9adf8db877133099dce574ecbb93eab797' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f230d9a00bd96_40527844',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f230d9a00bd96_40527844 (Smarty_Internal_Template $_smarty_tpl) {
?>Holding Bachelor Degree in relation with Math with minimum GPA 2.80<br />
Fluent in English with min TOEFL 500 or equivalent<br />
Familiarity with the Cambridge IGCSE/A Levels/IB Diploma Curriculum is a plus<br />
Fresh Graduates are welcome to apply<br />
<br />
Interested candidates, please send your complete resume to:<br />
<br />
JKT.LIGHTHOUSE.LC@gmail.com<?php }
}
