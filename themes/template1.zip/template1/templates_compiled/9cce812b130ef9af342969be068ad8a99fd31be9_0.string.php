<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-09 22:16:25
  from '9cce812b130ef9af342969be068ad8a99fd31be9' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f3075b9a247a1_56196407',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f3075b9a247a1_56196407 (Smarty_Internal_Template $_smarty_tpl) {
?>1. Muslim/Muslimah<br />
2. Sehat dan Tidak Merokok<br />
3. Minimal S1 semua Jurusan<br />
4. Berpengalaman mengajar lebih dari satu tahun lebih disukai<br />
<?php }
}
