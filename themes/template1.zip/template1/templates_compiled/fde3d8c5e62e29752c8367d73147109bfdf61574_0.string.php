<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-01 11:28:04
  from 'fde3d8c5e62e29752c8367d73147109bfdf61574' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f2551c413ad07_99152606',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2551c413ad07_99152606 (Smarty_Internal_Template $_smarty_tpl) {
?>Lesson plan<br />
Class management<br />
Always update teaching skills<br />
Computer literature and Proficiency in English<br />
<?php }
}
