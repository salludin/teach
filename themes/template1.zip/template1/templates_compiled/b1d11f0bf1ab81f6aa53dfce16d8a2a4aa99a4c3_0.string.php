<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-24 03:08:56
  from 'b1d11f0bf1ab81f6aa53dfce16d8a2a4aa99a4c3' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f432f48e31420_25214610',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f432f48e31420_25214610 (Smarty_Internal_Template $_smarty_tpl) {
?>Mengajar pelajaran Sejarah untuk siswa tingkat SMA.<?php }
}
