<?php
/* Smarty version 3.1.34-dev-7, created on 2020-07-31 04:15:22
  from '5722e924bf1bd1ea4d041e874dcef7179033aba2' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f239ada610766_16677602',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f239ada610766_16677602 (Smarty_Internal_Template $_smarty_tpl) {
?>Pendidikan min. S1<br />
Pengalaman kerja min. 2 tahun sebagai Admin/Tata Usaha di sekolah<br />
Menguasai/mengerti pelaporan administrasi ke Dinas Pendidikan<br />
Terampil dalam surat menyurat<br />
Menguasai/mengerti desain grafis<br />
Mampu berbahasa inggris (lisan maupun tulisan)<br />
<?php }
}
