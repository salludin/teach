<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-23 03:19:38
  from '21700490f3bc15791c0b9a01b9667fbf36bf124c' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f41e04a6bb8b1_10138230',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f41e04a6bb8b1_10138230 (Smarty_Internal_Template $_smarty_tpl) {
?>1.	Bachelor in PR/Communication<br />
2.	Man/Woman, max. 25 years old<br />
3.	Good communication in English<br />
4.	Good looking and willing to learn<br />
<?php }
}
