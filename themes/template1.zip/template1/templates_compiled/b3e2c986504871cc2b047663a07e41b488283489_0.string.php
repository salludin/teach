<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-06 07:25:20
  from 'b3e2c986504871cc2b047663a07e41b488283489' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f2bb060ec5168_77757858',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2bb060ec5168_77757858 (Smarty_Internal_Template $_smarty_tpl) {
?>Required :<br />
<br />
&bull;	Native English speaker <br />
&bull;	Holder of Bachelor Degree in subject area of English Language Education, or Post Graduate Certificate/Diploma in Education/English<br />
&bull;	Min 5 year experience in educational institution<br />
&bull;	Possess the relevant training in the subject or areas that will be teaching<br />
&bull;	Ideal candidates have a passion for teaching, a strong sense of adventure, embrace diversity, and have a strong desire to learn and participate in other cultures.<br />
&bull;	Excellent communication skills and a positive and caring approach<br />
&bull;	Experience with IBDP and IGCSE curriculum<br />
&bull;	Willingness to take on an additional extracurricular duty or club<br />
<br />
Please send your CV and a recent photo to hrd@sekolahbogorraya.com We apologize, but only shortlisted candidates will be contacted.<?php }
}
