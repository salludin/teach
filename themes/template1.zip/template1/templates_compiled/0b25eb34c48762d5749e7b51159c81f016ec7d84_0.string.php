<?php
/* Smarty version 3.1.34-dev-7, created on 2020-07-31 08:49:59
  from '0b25eb34c48762d5749e7b51159c81f016ec7d84' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f23db37c6e3a9_35047670',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f23db37c6e3a9_35047670 (Smarty_Internal_Template $_smarty_tpl) {
?>Mengajar Alquran untuk Anak kategori Toddler (usia 3-5 tahun), Kids (6-12 tahun), Teens (13-17 tahun), Adult (>17 tahun) Dengan Metode Funlearning, Bilingual dan Intensif. <?php }
}
