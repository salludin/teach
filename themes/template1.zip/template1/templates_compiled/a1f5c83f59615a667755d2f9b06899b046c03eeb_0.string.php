<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-23 03:17:38
  from 'a1f5c83f59615a667755d2f9b06899b046c03eeb' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f41dfd2d688e6_88316256',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f41dfd2d688e6_88316256 (Smarty_Internal_Template $_smarty_tpl) {
?>â€¢	Max. 30 years old<br />
â€¢	Understand about various marketing tools, research and strategy<br />
â€¢	University graduate from any major<br />
â€¢	A Good command in English both verbal and written is a must<br />
â€¢	Computer (Outlook, MS Word, MS Excel) and Internet Literate<br />
â€¢	Communicative, hardworking and outgoing personality<br />
â€¢	Multi-tasking and open minded person<br />
<?php }
}
