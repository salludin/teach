<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-10 03:08:28
  from '75c6bcc7f898b8a169eb7f9039d85fa3082aba28' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f30ba2c45f0f6_80326197',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f30ba2c45f0f6_80326197 (Smarty_Internal_Template $_smarty_tpl) {
?>Bachelor Degree in Education<br />
Minimum age of 23 years old<br />
Have a passion for children <?php }
}
