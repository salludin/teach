<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-13 10:19:12
  from 'cc538a254eb44acac468a37f07c33ac4ec28465e' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f3513a017fcc1_49469424',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f3513a017fcc1_49469424 (Smarty_Internal_Template $_smarty_tpl) {
?>Requirements:<br />
-  Female, Age maximum 30 years old<br />
-  Education minimum D3/S1<br />
-  Love children and passionate in education<br />
-  Energetic, cheerful and warm<br />
-  Able to work in a team<br />
-  Good communication skill with children and adults<br />
-  Have experience in early childhood education<br />
-  Fluent in English, verbal and written<br />
-  Able to work with computer and classroom multimedia equipments<br />
-  Immediately available<br />
-  Work Location : Gading Serpong Area<?php }
}
