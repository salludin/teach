<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-09 10:43:06
  from 'b04d4085a802425a780612a9e17be92229a130d3' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f2fd33a927132_54475150',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2fd33a927132_54475150 (Smarty_Internal_Template $_smarty_tpl) {
?>Impeccable integrity<br />
Strong communication skills<br />
Related degree from a reputable university<br />
Minimum 8 years of teaching experience<br />
Prior experience in senior management position<br />
Experience in Singapore Schools preferred<br />
Local candidates are encouraged to apply<?php }
}
