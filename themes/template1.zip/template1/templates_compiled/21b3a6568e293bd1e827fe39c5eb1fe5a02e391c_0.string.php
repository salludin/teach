<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-05 04:30:43
  from '21b3a6568e293bd1e827fe39c5eb1fe5a02e391c' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f2a35f3821d07_56250179',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2a35f3821d07_56250179 (Smarty_Internal_Template $_smarty_tpl) {
?>Menyiapkan materi pelajaran, mengajar, mencatat absen murid, mengawasi siswa di dalam dan di luar kelas selama pelajaran berlangsung menerapkan peraturan sekolah, dll<br />
<br />
 <br />
<br />
<?php }
}
