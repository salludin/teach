<?php
/* Smarty version 3.1.34-dev-7, created on 2020-07-27 22:14:04
  from 'cfbd073a94cbf3ec26167df93b3e86521d3f8d83' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f1f51ac4dabc0_42038450',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f1f51ac4dabc0_42038450 (Smarty_Internal_Template $_smarty_tpl) {
?>Mahir menggunakan komputer<br />
Pendidikan Min. S1 (mahasiswa semester akhir) dengan IPK Min. 3.00<br />
Bisa berkomunikasi dengan baik dalam lisan dan tulisan<br />
Bisa interaksi/ komunikasi dengan anak-anak dengan baik<?php }
}
