<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-06 22:11:06
  from 'c6100aa055540fe6b98aaea01b2329bd91f53069' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f2c7ffad12593_18905358',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2c7ffad12593_18905358 (Smarty_Internal_Template $_smarty_tpl) {
?>- Develop and maintain a constructive and ongoing rapport with children and parents<br />
<br />
- Collaborate with other teachers to ensure that the school fosters an environment that is inviting and nurturing for every child<br />
<br />
- Deliver reports on potential concerns about students as to management as needed<br />
<br />
- Manage day-to-day classroom activities, including structured lessons, free play, bathroom breaks, lunch time and rest time for students<?php }
}
