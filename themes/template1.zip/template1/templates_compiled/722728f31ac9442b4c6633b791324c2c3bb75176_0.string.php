<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-09 20:59:07
  from '722728f31ac9442b4c6633b791324c2c3bb75176' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f30639bd41d54_93448772',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f30639bd41d54_93448772 (Smarty_Internal_Template $_smarty_tpl) {
?>â€¢	Degree with major in teaching subjects<br />
â€¢	Teaching qualification<br />
â€¢	Minimum 5 years teaching experience <br />
â€¢	Passionate about teaching<br />
<?php }
}
