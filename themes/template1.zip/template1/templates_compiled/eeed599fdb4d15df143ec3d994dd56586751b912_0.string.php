<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-15 14:30:48
  from 'eeed599fdb4d15df143ec3d994dd56586751b912' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f37f19817ccd3_30488436',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f37f19817ccd3_30488436 (Smarty_Internal_Template $_smarty_tpl) {
?>Persyaratan sebagai berikut :<br />
1. Usia maksimal 35 tahun<br />
2. Sarjana S1<br />
3. Senang mengajar<br />
4. Mampu bekerjasama dalam team<br />
5. Menguasai Matematika dan Fisika SMP<br />
<br />
Jika berminat segera kirim lamaran lengkap ke alamat :<br />
Jl.Pluit Karang Ayu 2, Blok D 1 S no.108A â€“ 108B<br />
Muara Karang<br />
Jakarta Utara 14450<br />
Email : itphang.edu@gmail.com<br />
Telp.021-66605646 / 021-66605647 (jam kerja 14.00-21.00)<br />
HP : 085217994798<br />
WA : 08161377923<br />
<br />
Silahkan klik web kami untuk mencari alamat lengkap di http://itphang.business.site/<?php }
}
