<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-07 15:52:51
  from 'dece308d403df73f11e81d094d7353dba4f67c0b' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f2d78d3cd1ab8_06199428',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2d78d3cd1ab8_06199428 (Smarty_Internal_Template $_smarty_tpl) {
?>Requirements;<br />
â€¢	A graduate from overseas is an advantage and is paid special allowance <br />
â€¢	Not more than 30 years old Indonesian (Preferably female)<br />
â€¢	Professional look, energetic and a fast learner<br />
â€¢	Have min.500 ITP TOEFL or IELTS Overall Band 6.0 for a fresh graduate<br />
â€¢	Proficient in spoken English actively<br />
<?php }
}
