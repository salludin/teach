<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-05 04:59:26
  from '1d7e7077f41f40d84bd5bd8ba84278990d7f3f0b' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f2a3cae5c3e10_83993992',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2a3cae5c3e10_83993992 (Smarty_Internal_Template $_smarty_tpl) {
?>Usia 20 - 30 tahun<br />
Sehat secara fisik dan mental<br />
Pendidikan minimal S1, Sistem Informasi (min. GPA 3.00)<br />
Pengalaman kerja di bidang yang sama minimal 2 tahun<br />
Pengalaman dalam membuat program menggunakan Bootstrap<br />
Menguasai Java Language untuk Android, Objective-C Language untuk iOS, Microsoft Visual Studio .Net C# Language untuk Windows Store App<br />
Bisa berbahasa Inggris atau Mandarin lebih diutamakan<br />
Bersedia bekerja di bawah tekanan dan target<br />
Mampu bekerja dalam mobilitas tinggi<br />
Mampu bekerja dalam tim<br />
Memiliki sikap kerja disiplin, jujur, dan bertanggung jawab<br />
Bersedia ditempatkan di Cengkareng Timur, Jakarta Barat<?php }
}
