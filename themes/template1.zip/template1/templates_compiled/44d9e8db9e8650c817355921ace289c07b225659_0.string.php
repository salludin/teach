<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-21 03:25:04
  from '44d9e8db9e8650c817355921ace289c07b225659' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f3f3e9011d087_56902495',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f3f3e9011d087_56902495 (Smarty_Internal_Template $_smarty_tpl) {
?>1. Male or female, max 45 y.o<br />
2. Graduated from English department <br />
3. Has experience in teaching English  for primary<br />
4. English fluent<br />
<?php }
}
