<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-05 07:59:18
  from 'd825c849e0efaa3147e9fa9a969a1137b4cf3c08' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f2a66d6e052a2_57151874',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2a66d6e052a2_57151874 (Smarty_Internal_Template $_smarty_tpl) {
?>Pendidikan min. S1<br />
Pengalaman kerja min. 2 tahun sebagai marketing di sekolah<br />
Mampu berbahasa inggris (lisan maupun tulisan)<br />
<?php }
}
