<?php
/* Smarty version 3.1.34-dev-7, created on 2020-07-27 08:48:47
  from 'cccee7bdc4eece10ebd5e273412106a4df05ce01' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f1e94ef2b3603_45739391',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f1e94ef2b3603_45739391 (Smarty_Internal_Template $_smarty_tpl) {
?>Lesson Plan<br />
Class Management<br />
Always update teaching skills<?php }
}
