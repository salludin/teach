<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-05 23:29:45
  from '596fe4972590af7bfe7511b18fee40733c3c9638' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f2b40e9da3693_42369614',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2b40e9da3693_42369614 (Smarty_Internal_Template $_smarty_tpl) {
?>- Fluent in English (speaking, writing, reading and listening)<br />
<br />
- Bachelor degree from reputable university correlated with the subject taught.<br />
<br />
- Highly initiative, hardworking, creative, communicative, team player, able to do multi-function tasks.<br />
<br />
- Have good leadership, good communication and social skills.<br />
<br />
- Having teaching experience in national/international/SPK school will be beneficial.<?php }
}
