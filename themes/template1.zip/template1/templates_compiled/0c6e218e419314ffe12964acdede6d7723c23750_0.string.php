<?php
/* Smarty version 3.1.34-dev-7, created on 2020-09-10 03:13:48
  from '0c6e218e419314ffe12964acdede6d7723c23750' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f5999ec9ad6e0_27469605',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f5999ec9ad6e0_27469605 (Smarty_Internal_Template $_smarty_tpl) {
?>1) Bertugas dan bertanggung jawab membantu menyiapkan materi kebutuhan mengajar dalam kelas sesuai dengan lesson plan<br />
2) Mengelola RKH, RKM dan PROGTA<br />
3) Menganalisa perkembangan harian, mingguan dan tahunan<br />
4) Mencapai standard pengajaran yang sudah ditetapkan<br />
5) Mengelola dan menjaga lingkungan belajar<br />
6) Mempersiapkan kegiatan harian, outing/field trip/kegiatan sekolah lainnya<br />
7) Bertanggung jawab atas kebersihan dan kerapihan lingkungan kelas<?php }
}
