<?php
/* Smarty version 3.1.34-dev-7, created on 2020-09-10 03:13:48
  from '773c21c6c9222310fa5484e6f9bed9f5f98c8337' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f5999eca5b266_59005150',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f5999eca5b266_59005150 (Smarty_Internal_Template $_smarty_tpl) {
?>1) Pria / wanita maksimal 35 tahun<br />
2) Beragama Islam dan beradab islami<br />
3) Bersedia mempelajari hal baru<br />
4) Lebih diutamakan tinggal di Jakarta Selatan (Kebayoran dan sekitarnya)<br />
5) S1 dari semua jurusan (diutamakan dari PGTK, S.pd dan S.PdI)<br />
6) Menyayangi dan memiliki motivasi terhadap anak-anak<br />
7) Memiliki pengalaman mengajar TK minimal 1tahun<br />
8) Bertanggung jawab, kreatif, sabar, jujur, energik<br />
9) Lebih disukai jika mengetahui metode Montessori dan penggunaan alat Montessori<br />
10) Bersedia di kontrak<?php }
}
