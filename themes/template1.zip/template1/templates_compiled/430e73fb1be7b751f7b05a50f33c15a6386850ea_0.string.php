<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-01 15:42:24
  from '430e73fb1be7b751f7b05a50f33c15a6386850ea' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f258d60b5cb52_15427815',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f258d60b5cb52_15427815 (Smarty_Internal_Template $_smarty_tpl) {
?>&bull;	Having a desire to serve the Lord &amp; support MSCS Vision and Mission<br />
&bull;	Bachelor degree of Physical Education and Health<br />
&bull;	Experience required minimum 1 year<br />
&bull;	Men or Woman at 22-40 years old<br />
&bull;	English proficiency &amp; experience in simliar field will be beneficial<br />
&bull;	Honest, teamwork, good communication skills, open minded, resourceful, energetic<br />
&bull;	Will be based in Surabaya<br />
<?php }
}
