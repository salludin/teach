<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-09 14:56:13
  from '03da6b5cc22104d90500eb517df9f0856a66f0e8' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f300e8dbae807_74357209',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f300e8dbae807_74357209 (Smarty_Internal_Template $_smarty_tpl) {
?>Computer literate<br />
Able to playing musical instrument will be advantaged<br />
Must love children and dedicate to teaching<?php }
}
