<?php
/* Smarty version 3.1.34-dev-7, created on 2020-07-29 00:05:26
  from '1ba4e3a527520ee9c5e84b895d6b0231200f25f3' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f20bd4659e088_66220276',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f20bd4659e088_66220276 (Smarty_Internal_Template $_smarty_tpl) {
?>Is able to work with national and/or international teachers, demonstrating initiative when supporting the teaching and learning programme.<br />
Is able to act fairly, impartially and respectfully in all dealings with students.<br />
Is able to carry out and follow school systems, procedures, and policies.<br />
Is willing to nurture positive relationships with the teachers, students and the parent community.<br />
Must demonstrate a willingness to participate in school activities (which might occasionally fall outside of normal working hours), attend staff meetings and participate in Professional Development opportunities when they arise.<br />
Is able to be responsible for the maintenance of classroom stationery items and teaching resources.<br />
Is able to make decisions and contribute to educational discussions with national and/or international teachers.<br />
Is skilled in the use of technology, particularly Microsoft Office (Word, Excel and PowerPoint). <br />
Usage of other multimedia tools such as Photoshop is an advantage.<br />
<?php }
}
