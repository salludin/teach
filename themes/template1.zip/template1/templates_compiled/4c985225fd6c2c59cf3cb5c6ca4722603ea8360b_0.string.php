<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-12 18:10:29
  from '4c985225fd6c2c59cf3cb5c6ca4722603ea8360b' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f343095038f70_66066825',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f343095038f70_66066825 (Smarty_Internal_Template $_smarty_tpl) {
?>S1 jurusan psikologi atau pendidikan khusus diutamakan<br />
Memiliki kecintaan terhadap dunia anak dan pendidikan anak<br />
Fresh graduate/berpengalaman<br />
Usia maksimal 30 tahun<br />
<?php }
}
