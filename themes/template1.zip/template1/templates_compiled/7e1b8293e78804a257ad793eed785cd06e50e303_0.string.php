<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-05 15:08:40
  from '7e1b8293e78804a257ad793eed785cd06e50e303' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f2acb781815b0_36290105',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2acb781815b0_36290105 (Smarty_Internal_Template $_smarty_tpl) {
?>A Bachelorâ€™s degree and a recognised Music teaching qualification from an accredited University.<br />
â€¢	A minimum of 3 years teaching experience in an Early Childhood setting. <br />
â€¢	A proven track record of at least 3 years in leadership and management, evidencing positive relationships with pupils, staff, governors and parents.<br />
â€¢	Fluent in English with a  demonstrated high level of communication and interpersonal skills when relating to students, colleagues, parents and the broader community<br />
â€¢	Ability to successfully initiate, plan and implement programs in response to new educational needs and priorities.<br />
<?php }
}
