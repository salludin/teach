<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-02 00:06:59
  from '53036aa6f98977d2e9e47422260a020fa9b9a962' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f2603a31c3327_96448584',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2603a31c3327_96448584 (Smarty_Internal_Template $_smarty_tpl) {
?>â€¢	High standard of teaching English as a foreign language<br />
â€¢	Planning, preparing, and delivering lessons to classes<br />
â€¢	Assessing while continuously monitoring studentâ€™s progress through coursework and examination<br />
â€¢	Providing personal feedback to student<br />
â€¢	Student oriented approach in teaching English<br />
<?php }
}
