<?php
/* Smarty version 3.1.34-dev-7, created on 2020-07-28 14:18:32
  from 'f99f212de5a556cc234f60292746a91630dd9674' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f2033b8b49880_35124396',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2033b8b49880_35124396 (Smarty_Internal_Template $_smarty_tpl) {
?>Must be citizen of Indonesia<br />
Must have a Masters degree, preferably in education or science Must have previous experience as a school principal<br />
Must have classroom teaching experience (at least five years)<br />
Must be able to develop a standarised curriculum<br />
Must have a good command of both spoken and written English<br />
Must be able to demonstrate strong leadership skills<br />
Must understand the Cambridge Assessment International Education (CAIE) Curriculum and Terms & Conditions<br />
Must be familiar with the regulations for SPK (Satuan Pendidikan Kerjasama)<br />
Preference granted to applicants who hold NUKS (Nomor Unik Kepala Sekolah) and/or Principal Certification.<?php }
}
