<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-13 23:40:59
  from '0edd33708c29af1da9c13418f9775eb7e7744596' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f35cf8b055296_10675665',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f35cf8b055296_10675665 (Smarty_Internal_Template $_smarty_tpl) {
?>&bull;	Having a desire to serve the Lord &amp; support MSCS Vision and Mission<br />
&bull;	Bachelor degree of Mathematics<br />
&bull;	Experience required minimum 1 year<br />
&bull;	Men or Woman at 22-40 years old<br />
&bull;	English proficiency &amp; experience in simliar field will be beneficial<br />
&bull;	Honest, teamwork, good communication skills, open minded, resourceful, energetic<br />
&bull;	Will be based in Surabaya<br />
<?php }
}
