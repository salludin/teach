<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-02 22:34:29
  from '363560bba1d9e37b71c6db96f4dcc3d474c798b5' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f273f757289b0_42694970',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f273f757289b0_42694970 (Smarty_Internal_Template $_smarty_tpl) {
?>As we continue to achieve success in education, we are looking for a motivated and hardworking individual to join our dynamic team as Religion Study Teacher (Christianity)<br />
<br />
Will teach Christianity to students age of 5-17 years old.<br />
<br />
Requirements for Teaching Position :<br />
Bachelor degree in the related field of study<br />
Proficient English in speaking and writing<br />
Have a minimum of at least 1 years of teaching experience in SPK School<br />
Have we sparked your interest?<br />
<br />
Please send your application to hrd@jimsch.org and we will get in touch with you for the interview!<?php }
}
