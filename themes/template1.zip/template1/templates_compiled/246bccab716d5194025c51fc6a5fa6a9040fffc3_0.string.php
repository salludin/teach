<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-23 03:18:46
  from '246bccab716d5194025c51fc6a5fa6a9040fffc3' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f41e01663bb55_25204643',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f41e01663bb55_25204643 (Smarty_Internal_Template $_smarty_tpl) {
?>lesson plan<br />
class management<br />
always update teaching skills<?php }
}
