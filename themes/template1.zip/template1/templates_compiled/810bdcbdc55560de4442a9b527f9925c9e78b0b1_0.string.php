<?php
/* Smarty version 3.1.34-dev-7, created on 2020-07-27 08:48:47
  from '810bdcbdc55560de4442a9b527f9925c9e78b0b1' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f1e94ef2bf002_42057447',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f1e94ef2bf002_42057447 (Smarty_Internal_Template $_smarty_tpl) {
?>Indonesian, Male / female age 26 - 45 years old<br />
Good personality, Loves and cares about the world of education <br />
Physically and mentally healthy, no criminal history<br />
Honest, active, responsible and creative<br />
Ability to work individually and in a team<br />
Computer literature<br />
<br />
Bachelor degree in Education according to each major, min. 4 yearsâ€™ experience in teaching <br />
Can spare time for training <br />
Proficiency in English <br />
<br />
Kindly send your resume, Curriculum Vitae and latest photograph latest by June, 17th, 2019 to this email address: recruitment@montesiennaschool.com<?php }
}
