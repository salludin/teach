<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-06 22:11:06
  from 'eb0ffc1839df8c2573cf3452b2f2eb7c8d658088' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f2c7ffad3fac8_93060184',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2c7ffad3fac8_93060184 (Smarty_Internal_Template $_smarty_tpl) {
?>- Fluent in English (Spoken and written)<br />
<br />
- TOEFL certificate (min. 500)<br />
<br />
- Minimum 1 year experience in teaching small children age 1.5-6 years old<br />
<br />
- Graduated minimal from S1 in English Education or English Literature, Early Childhood Education<br />
<br />
- Maximum age is 35 years old<br />
<br />
- Cheerful, patient, good teamwork, energetic, willing to learn new things and importantly love children<br />
<br />
- Only those who are shortlisted and qualified will be called for an interview<?php }
}
