<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-13 18:27:05
  from '82f7c339e59e178760ce015e2389d6527a8ff26d' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f3585f9d028e5_61122619',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f3585f9d028e5_61122619 (Smarty_Internal_Template $_smarty_tpl) {
?>Bachelors degree from an accredited college or university in Art<br />
Excellent English communication skills, both written & spoken<br />
Must be able to understand the Cambridge Assessment International Education (CAIE) IGCSE Art & Design curriculum<br />
Able to teach any art related topic ranging from mixing basic colors to art history and bring out the inner artists of students to help build skills and self-confidence<br />
Able to communicate and maintain working relationships effectively in both written and  oral forms with all levels of management, both internal and external<br />
Able to organize special programs for assigned campus<br />
Able to use computer including software, database used by the district, spreadsheet and word processing software, calculator, copy machine and telephone<br />
Able to use effective interview techniques, effective public speaking skills, and problem-solving skills<?php }
}
