<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-10 20:00:00
  from '79021c35f023c21901d3413bd72930f04b5806e7' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f31a7405c1188_00504607',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f31a7405c1188_00504607 (Smarty_Internal_Template $_smarty_tpl) {
?>Required :<br />
<br />
&bull;	S1/S2 Bachelor&rsquo;s or Master&rsquo;s degree minimum in Physical Education or related field<br />
&bull;	Excellent standard of English<br />
&bull;	Experience teaching Physical Education in English at PGK or Secondary school level<br />
&bull;	Excellent communication skills and a positive and caring approach<br />
&bull;	Respect for diversity; religion, race, and gender<br />
&bull;	Experience with IGCSE, or IBDP curriculum (Secondary Level)<br />
&bull;	Willingness to take on an additional extracurricular duty or club<br />
<br />
Please send your CV and a recent photo to hrd@sekolahbogorraya.com We apologize, but only shortlisted candidates will be contacted.<br />
<?php }
}
