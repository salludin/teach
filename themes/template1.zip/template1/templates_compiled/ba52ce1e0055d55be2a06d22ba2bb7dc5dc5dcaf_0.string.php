<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-06 00:17:15
  from 'ba52ce1e0055d55be2a06d22ba2bb7dc5dc5dcaf' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f2b4c0b1fdc52_98928138',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2b4c0b1fdc52_98928138 (Smarty_Internal_Template $_smarty_tpl) {
?>This position is for the young & bright Fresh Graduate with education background any major especially Mathematics or a student in their final year of study who are willing to start pursuing career in educational area.<br />
<br />
Currently we are seeking people, who are enthusiastic in education, to working together with us, improving education in Indonesia as: <?php }
}
