<?php
/* Smarty version 3.1.34-dev-7, created on 2020-07-30 02:17:11
  from 'fe5349059a7aad811a2d184e40f6ada7e5271b73' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f222da7f3bed5_08586316',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f222da7f3bed5_08586316 (Smarty_Internal_Template $_smarty_tpl) {
?>- Bachelor Degree<br />
- At least 2 years working experience in school industry<br />
- Proficient English both written and speaking<br />
- IT literate<br />
- Adobe, Corel and Photoshop literate<br />
- Team player<br />
- Solution oriented<?php }
}
