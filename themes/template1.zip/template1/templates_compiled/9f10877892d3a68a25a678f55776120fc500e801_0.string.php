<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-02 01:31:14
  from '9f10877892d3a68a25a678f55776120fc500e801' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f261762a534f7_53509546',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f261762a534f7_53509546 (Smarty_Internal_Template $_smarty_tpl) {
?>Max. 40 years old<br />
Having a Bachelor in mathematics or related science (fresh graduated are allowed) is preferred<br />
Familiar or experienced in Cambridge Curriculum is preferred<br />
Excellent communication skill in English (spoken & written), minimum with TOEFL score 550 are preferred<br />
Love mathematics and obsessed with teaching<br />
Responsible, creative, highly motivated, fast learner and demonstrates initiative, able to work in a team, has commitment and passion in teaching<br />
Pleasant and matured personality, communicative and highly adaptable to new challenges<br />
Good computer skill (word, excel and power point)<br />
Good communication skill<br />
Indonesian citizenship (not EXPAT teacher)<?php }
}
