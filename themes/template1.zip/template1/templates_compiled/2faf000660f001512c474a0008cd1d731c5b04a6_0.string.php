<?php
/* Smarty version 3.1.34-dev-7, created on 2020-07-27 06:28:10
  from '2faf000660f001512c474a0008cd1d731c5b04a6' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f1e73faa3a522_66755881',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f1e73faa3a522_66755881 (Smarty_Internal_Template $_smarty_tpl) {
?>Company Overview<br />
<br />
As a member of the Sekolah Bogor Raya team, you will be joining Bogor&rsquo;s leading international standard school. Sekolah Bogor Raya exists to provide international standard education to the people of Bogor, Sentul, Cibubur, and South Jakarta. Sekolah Bogor Raya has an international reputation as one of Indonesia&rsquo;s premiere schools. Through a commitment to English Language fluency, technological expertise, and inquiry-based teaching and learning, we deliver an international program that integrates global concepts with a local focus. Our programs prioritize the physical, spiritual, intellectual, and emotional development of our students and encourage them to build self-esteem and strive to be the very best that they can be.<br />
<?php }
}
