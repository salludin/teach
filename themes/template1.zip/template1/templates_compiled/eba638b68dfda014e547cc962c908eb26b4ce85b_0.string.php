<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-16 09:51:23
  from 'eba638b68dfda014e547cc962c908eb26b4ce85b' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f39019b850aa3_45879391',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f39019b850aa3_45879391 (Smarty_Internal_Template $_smarty_tpl) {
?>Usia 25-38 tahun<br />
Sehat secara fisik dan mental<br />
Pendidikan minimal S1 atau yang sederajat<br />
S1 Pendidikan Fisika/Biologi/Kimia<br />
Memiliki pengalaman mengajar minimal 3 tahun<br />
Berbahasa Inggris aktif, sebagai bahasa pengantar<br />
Kreatif, kritis, inisiatif, kooperatif, dan dedikatif<br />
Terampil mengajar dan mengelola kelas<br />
Terampil mengoperasikan Ms. Office<br />
Mencintai dunia pendidikan<?php }
}
