<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-24 03:08:06
  from '2405d5fef39130a948b91fb1ab22c65709346a37' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f432f1660dd53_16548127',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f432f1660dd53_16548127 (Smarty_Internal_Template $_smarty_tpl) {
?>Teach ESL to secondary students in SPK SCHOOL with Cambridge and IB DP Curriculum<?php }
}
