<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-07 22:22:33
  from '9d376073d40d5879bfbdd72eec2985ca0a9711d5' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f2dd4299541e0_35409582',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2dd4299541e0_35409582 (Smarty_Internal_Template $_smarty_tpl) {
?>â€¢  Teachers create lesson plans and teach those plans to the entire class, individually to students or in small groups, track student progress and present the information to parents, create tests, create and reinforce classroom rules, work with school administration prepare students for standardized tests, and manage students outside the classroom, such as in school hallways, detention, etc. <br />
â€¢  Responsibilities and Duties <br />
â€¢  Create a Lesson Plan (RPP). <br />
â€¢  Execute Lesson Plan (RPP) in teaching activities (KBM). <br />
â€¢  Provide assessments to the students. <br />
â€¢  Establish report for studentâ€™s grades and development. <br />
â€¢  Ready to participate in both academic and non-academic activities (school policies). <br />
â€¢  Responsible for teaching and education fulfillments provided to the students.<?php }
}
