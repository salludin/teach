<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-11 11:09:48
  from 'e7d650790b2fb92c7050e8af58500ef322182395' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f327c7c707b65_76181553',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f327c7c707b65_76181553 (Smarty_Internal_Template $_smarty_tpl) {
?>Maximal 40 years old<br />
Hold a Bachelor in any subject (fresh graduated are allowed)<br />
Responsible, creative, highly motivated, fast learner and demonstrates initiative, good teamwork, has commitment and passion in teaching<br />
Pleasant personality, communicative and highly adaptable to new challenges<br />
Have good character<br />
Indonesian citizenship (not EXPAT teacher)<br />
Have Baptism Letter<br />
 <br />
<br />
"Only the selected candidates will be invited through e-mail/phone for Test and Interview"<br />
<br />
Qualified candidates are requested to submit a letter, comprehensive resume, references, a recent photograph and evidence of qualification to:<br />
<br />
Head of Human Resources<br />
Sekolah Pelangi Kasih<br />
Taman Grisenda Blok A1/28, Pantai Indah Timur<br />
Kapuk Muara, Jakarta Utara (14460)<br />
<br />
or clicking button bellow<?php }
}
