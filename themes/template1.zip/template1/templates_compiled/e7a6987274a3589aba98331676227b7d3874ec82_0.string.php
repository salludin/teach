<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-09 10:24:53
  from 'e7a6987274a3589aba98331676227b7d3874ec82' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f2fcef5a93db9_98672343',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2fcef5a93db9_98672343 (Smarty_Internal_Template $_smarty_tpl) {
?>Required :<br />
&bull;	S1/S2 Bachelor&rsquo;s or Master&rsquo;s degree minimum in Early Childhood Education (PG PAUD) or Primary School Education (PG SD).<br />
&bull;	Experience teaching at an international or national plus school<br />
&bull;	Able to teach all subject in Indonesian &amp; English Language<br />
&bull;	Excellent standard of English<br />
&bull;	Excellent communication skills and a positive and caring approach<br />
&bull;	Respect for diversity; religion, race, and gender<br />
&bull;	Experience with IB PYP<br />
&bull;	Technology Literate<br />
&bull;	Willingness to take on an additional extracurricular duty or club<br />
<br />
Please send your CV and a recent photo to hrd@sekolahbogorraya.com We apologize, but only shortlisted candidates will be contacted.<?php }
}
