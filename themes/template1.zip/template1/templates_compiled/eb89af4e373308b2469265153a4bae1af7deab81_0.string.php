<?php
/* Smarty version 3.1.34-dev-7, created on 2020-07-27 09:07:00
  from 'eb89af4e373308b2469265153a4bae1af7deab81' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f1e9934d42bc2_31963591',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f1e9934d42bc2_31963591 (Smarty_Internal_Template $_smarty_tpl) {
?>Guru Kelas tingkat Sekolah Dasar.<br />
Bertanggung jawab terhadap siswa/siswi di dalam kelas, <br />
Mempersiapkan RPP untuk pembelajaran.<br />
Mengobservasi dan melaporkan perkembangan prilaku siswa/siswi. <br />
Membuat performance kelas 1 kali dalam setahun.<br />
Bertanggung jawab atas proses pembelajaran di kelas.<?php }
}
