<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-10 03:08:28
  from '074c67bbf46c43e90b10705bdef30042625fd6b2' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f30ba2c453f21_20656695',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f30ba2c453f21_20656695 (Smarty_Internal_Template $_smarty_tpl) {
?>To assist the class teacher inside the classroom<?php }
}
