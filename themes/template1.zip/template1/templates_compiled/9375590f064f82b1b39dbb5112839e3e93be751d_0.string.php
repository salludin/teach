<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-24 03:08:06
  from '9375590f064f82b1b39dbb5112839e3e93be751d' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f432f16616c62_13399518',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f432f16616c62_13399518 (Smarty_Internal_Template $_smarty_tpl) {
?>Communicative, Collaborative, Innovative, Engaging, Adaptable Leader, Solution Oriented, Committed.<br />
<br />
Bachelor degree in related field with teaching certificate or Bachelor degree in education from a recognised university<br />
<br />
Applicant having a Cambridge or IB DP teaching certificate or Teaching Certificate from Ministry of Education would be an advantage<br />
<br />
Have minimum at least 2 years of working experience in teaching using one of these curriculum in a SPK School: K-13, IB PYP, Cambridge or IB DP <?php }
}
