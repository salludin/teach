<?php
/* Smarty version 3.1.34-dev-7, created on 2020-07-30 01:42:05
  from '4e84c47234168f4d95ccd637a2889967155d0a8d' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f22256d4af6f4_58178169',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f22256d4af6f4_58178169 (Smarty_Internal_Template $_smarty_tpl) {
?>Pendidikan min. SMA/SMK<br />
Pengalaman kerja min. 2 tahun sebagai Maintenance (Pemeliharaan)<br />
Menguasai/mengerti tentang perbaikan bangunan, bocor, elektrikal<br />
<?php }
}
