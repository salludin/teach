<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-08 11:59:37
  from '4f14d10684b4093c243c71f9cf92e685ef790f74' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f2e93a9ec1d73_16571551',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2e93a9ec1d73_16571551 (Smarty_Internal_Template $_smarty_tpl) {
?>Memastikan bahwa semua komputer berjalan sebagaimana mestinya<br />
Memastikan website telah terupdate<br />
Membuat program yang diperlukan<br />
<?php }
}
