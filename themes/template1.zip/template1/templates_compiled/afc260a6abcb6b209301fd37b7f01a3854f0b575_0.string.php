<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-11 10:53:04
  from 'afc260a6abcb6b209301fd37b7f01a3854f0b575' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f327890bc8391_09329279',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f327890bc8391_09329279 (Smarty_Internal_Template $_smarty_tpl) {
?>1. Sehat jasmani rohani<br />
2. Inovasi<br />
3. mempunyai hasil test UKBI<?php }
}
