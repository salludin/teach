<?php
/* Smarty version 3.1.34-dev-7, created on 2020-07-31 07:35:12
  from 'f2d7ba6ac22996d26e8a5a3b6492214918173943' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f23c9b0636df6_34726807',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f23c9b0636df6_34726807 (Smarty_Internal_Template $_smarty_tpl) {
?>Usia 22-35 tahun<br />
Sehat secara fisik dan mental<br />
S1 Teknik Komputer / S1 Sistem Informasi <br />
Kreatif, kritis, inisiatif, kooperatif, dan dedikatif<br />
Terampil mengajar dan mengelola kelas<br />
Terampil mengoperasikan Ms. Office<br />
Mencintai dunia pendidikan<br />
Bersedia ditempatkan di Cengkareng Timur, Jakarta Barat<?php }
}
