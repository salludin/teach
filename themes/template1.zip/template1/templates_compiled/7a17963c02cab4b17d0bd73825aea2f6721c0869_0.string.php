<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-02 18:39:44
  from '7a17963c02cab4b17d0bd73825aea2f6721c0869' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f270870eb45c9_79616504',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f270870eb45c9_79616504 (Smarty_Internal_Template $_smarty_tpl) {
?>Responsible to:  Principal and Assistant Principal <br />
Job Purpose: <br />
â€¢	To manage and develop their subject area, ensuring all criteria are met for successful delivery of the curriculum at all ages <br />
â€¢	To ensure students are well prepared for public examinations through liaison with Kepseks and Assistant Principals<br />
<br />
Responsibilities and Duties, additional to those of Teacher <br />
<br />
1)	To maintain a working knowledge of curriculum documents and developments, especially IGCSE changes.<br />
2)	To be ultimately responsible for planning, delivery and revision of Schemes of Work in accordance with school policies, in discussion with subject teachers, and to ensure that teachers follow these Schemes of Work.<br />
3)	To build a sense of teamwork and collaboration between department members, fostering departmental pride and identity.<br />
4)	To liaise with APs to oversee logical progression and minimal overlap from Pre-school to Primary, Primary to Secondary and Secondary to Pre-University, in their subject area.<br />
5)	To lead and support the teaching of other members of the faculty in a cross curricular learning environment, liaising with other HoDs to look for areas of collaboration.<br />
6)	To check and comment on Lesson Plans in their department area on a weekly basis, and report back to the Principal.<br />
7)	To oversee provision and maintenance of attractive and stimulating environments in which to foster effective teaching and learning.<br />
8)	To advise the Principal on resources throughout their Department<br />
9)	To ensure teachers are providing for ESL students, more able students and those requiring additional support.<br />
10)	To oversee and promote a weekly Drop-in Clinic in their subject area to support students who have a weakness, special needs, or special interest. <br />
11)	 To help and assist in ECA (English subject). <br />
12)	To vet and proof read the English related documents such as Semester Report cards â€™comments, The content of school Excalibur, Semester examination papers etc. <br />
13)	To provide pastoral care for weaker students. <br />
<?php }
}
