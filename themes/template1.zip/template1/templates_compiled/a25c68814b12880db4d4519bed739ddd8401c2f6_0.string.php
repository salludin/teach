<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-18 03:27:17
  from 'a25c68814b12880db4d4519bed739ddd8401c2f6' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f3b4a95c22d75_77127734',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f3b4a95c22d75_77127734 (Smarty_Internal_Template $_smarty_tpl) {
?>&bull;	Candidate must possess at least a bachelor degree in Early Childhood Education Program or Psychology<br />
&bull;	Holding a teaching certificate is more preferred<br />
&bull;	Minimum of two years of teaching experience as a Kindergarten Teacher in an English environment <br />
&bull;	Having a Montessori certificate or certificate of early childhood education&#039;s training will be considered as an advantage<br />
&bull;	Capable of operating MS. Office (Word, Excel, PowerPoint, Publisher)<br />
&bull;	Proven self-initiative, creative and teamwork spirit with an open-minded character <br />
&bull;	Possess strong Islamic characters<br />
&bull;	Fluent in English both oral and written<br />
&bull;	Ready to join in July 2020<br />
<br />
<br />
Should you meet the qualifications, please send your updated CV with the application letter in English, update photographs, copy of identity card, academic degree, working certificate, and other related certificates to:  recruitment@icm.sch.id or hrd@icm.sch.id <?php }
}
