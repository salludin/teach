<?php
/* Smarty version 3.1.34-dev-7, created on 2020-07-27 16:00:24
  from '0049d9ca5374dab56c2c4cb5c2327a9fbbbeebbe' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f1efa180ee695_42515343',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f1efa180ee695_42515343 (Smarty_Internal_Template $_smarty_tpl) {
?>- D3/Bachelor from reputable university, preferably from Multimedia or DKV<br />
<br />
- Fluent in English (speaking, writing, reading and listening) will be beneficial<br />
<br />
- Highly initiative, hardworking, communicative, team player and able to do multi-function tasks.<?php }
}
