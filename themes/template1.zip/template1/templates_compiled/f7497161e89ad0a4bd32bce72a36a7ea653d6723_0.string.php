<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-24 03:06:26
  from 'f7497161e89ad0a4bd32bce72a36a7ea653d6723' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f432eb2034cb4_76832388',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f432eb2034cb4_76832388 (Smarty_Internal_Template $_smarty_tpl) {
?>&bull;	Having a desire to serve the Lord &amp; support MSCS Vision and Mission<br />
&bull;	Bachelor degree of English Literature / English Education<br />
&bull;	Experience required minimum 1 year<br />
&bull;	Men or Woman at 22-40 years old<br />
&bull;	English proficiency &amp; experience in simliar field will be beneficial<br />
&bull;	Honest, teamwork, good communication skills, open minded, resourceful, energetic<br />
&bull;	Will be based in Surabaya<br />
<?php }
}
