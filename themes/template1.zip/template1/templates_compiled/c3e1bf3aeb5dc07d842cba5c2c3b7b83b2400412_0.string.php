<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-05 14:24:31
  from 'c3e1bf3aeb5dc07d842cba5c2c3b7b83b2400412' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f2ac11f55ac41_32293906',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2ac11f55ac41_32293906 (Smarty_Internal_Template $_smarty_tpl) {
?>Maximal 40 years old<br />
Hold a Bachelor in any subject (fresh graduated are allowed)<br />
Excellent communication skill in English (spoken & written), minimum with TOEFL score 500 are preferred<br />
Good computer skill (word, excel and power point)<br />
Good communication skill<br />
Responsible, creative, highly motivated, fast learner and demonstrates initiative, able to work in a team, has commitment and passion in teaching<br />
Pleasant and matured personality, communicative and highly adaptable to new challenges<br />
Indonesian citizenship (not EXPAT teacher)<br />
Hold a Baptism Letter<?php }
}
