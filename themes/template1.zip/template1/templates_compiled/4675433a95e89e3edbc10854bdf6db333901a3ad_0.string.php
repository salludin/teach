<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-10 07:39:06
  from '4675433a95e89e3edbc10854bdf6db333901a3ad' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f30f99ac42456_74812151',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f30f99ac42456_74812151 (Smarty_Internal_Template $_smarty_tpl) {
?>Bertanggung jawab untuk kelancaran dan pelaksanaan seluruh proses Admission/penerimaan murid baru (tools promosi, aktivitas promosi, Visit OTM, pembelian formulir, tes siswa, closing, monitoring database yang sudah closing maupun belum<br />
menjalin hubungan baik dengan pihak/ instansi di luar stella maris<br />
menjaga hubungan baik dengan orang tua dan calon orang tua murid<?php }
}
