<?php
/* Smarty version 3.1.34-dev-7, created on 2020-07-30 01:42:05
  from 'faa2f50693ac38e14058591f32649bfdf09cf173' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f22256d4a2c46_26152810',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f22256d4a2c46_26152810 (Smarty_Internal_Template $_smarty_tpl) {
?>Persyaratan Umum:<br />
Pria/Wanita, umur 20-35 tahun<br />
Berpenampilan baik<br />
Semangat dan ulet<br />
Loyalitas, dedikasi tinggi<br />
Supel, Jujur, kreatif, bertanggungjawab dan menyukai dunia pendidikan<br />
Sehat jasmani dan rohani<br />
Bisa bekerja secara tim<br />
Dapat mengoperasikan komputer dengan baik<?php }
}
