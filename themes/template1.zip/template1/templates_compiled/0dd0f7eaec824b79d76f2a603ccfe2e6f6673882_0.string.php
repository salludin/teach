<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-09 22:46:24
  from '0dd0f7eaec824b79d76f2a603ccfe2e6f6673882' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f307cc08bc819_13770159',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f307cc08bc819_13770159 (Smarty_Internal_Template $_smarty_tpl) {
?>Requirements :<br />
- Hold min. bachelor degree from Literature, Social, or Tourism or close related major<br />
- Having much knowledge about Indonesia<br />
-  Creative,  inspiring<br />
-  Preferably experience<br />
<br />
send your complete documents ( ID Card, cover letter, updated resume,  bachelor certificate & its transcript, reference letter from previous work places, certificates) to recruitment@cahayabangsa.org<br />
<?php }
}
