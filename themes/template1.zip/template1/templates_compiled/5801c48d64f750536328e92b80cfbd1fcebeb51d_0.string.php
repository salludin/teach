<?php
/* Smarty version 3.1.34-dev-7, created on 2020-07-28 03:37:12
  from '5801c48d64f750536328e92b80cfbd1fcebeb51d' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f1f9d68665174_84695660',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f1f9d68665174_84695660 (Smarty_Internal_Template $_smarty_tpl) {
}
}
