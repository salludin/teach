<?php
/* Smarty version 3.1.34-dev-7, created on 2020-07-28 03:37:12
  from 'd2e194d127b4c7d8bbb408fe24b36204b7887daf' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f1f9d6866e374_30183073',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f1f9d6866e374_30183073 (Smarty_Internal_Template $_smarty_tpl) {
?>1.	Bachelor in Accounting<br />
2.	Ms. Excel and Internet literatur for work<br />
3.	Man/woman max. 25 years old<?php }
}
