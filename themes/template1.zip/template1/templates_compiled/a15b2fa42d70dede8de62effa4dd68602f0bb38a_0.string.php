<?php
/* Smarty version 3.1.34-dev-7, created on 2020-07-27 15:15:09
  from 'a15b2fa42d70dede8de62effa4dd68602f0bb38a' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f1eef7d9ff7d7_98376568',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f1eef7d9ff7d7_98376568 (Smarty_Internal_Template $_smarty_tpl) {
?>Good English (Min. TOEFL Score: 500 / IELTS: 6.0)<br />
Experience in related field: 3 years teaching experience, preferably in national plus schools<br />
Relevant educational background (Min. Bachelor degree) / Professional certificate <br />
Mathematics: Mathematics Science<br />
Language and Literature: Bahasa Indonesia Science / Bahasa Indonesia Literature: English Science or English Literature<br />
Physics: Physics Science<br />
Biology: Biology Science<br />
Social Study: Geography is preferred<br />
Music: Music Science / other majors are welcomed<br />
Physical Education: Physical Education Science<br />
Must have strong communication and presentation skills<br />
Expert knowledge of adolescent development as well as the subject they teach<br />
Available to start joining Cikal by academic year 19/20 and willing to involve in the whole selection process<?php }
}
