<?php
/* Smarty version 3.1.34-dev-7, created on 2020-07-30 11:28:29
  from 'ff1e1cd6961335eb0c12461913e708b6195388d3' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f22aedd8ca962_70729748',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f22aedd8ca962_70729748 (Smarty_Internal_Template $_smarty_tpl) {
?>SPd, bidang studi PPKn<br />
<br />
Lulusan baru diterima<br />
<br />
Bahasa Inggrisaktif<br />
<br />
Integritas, keterampilan komunikasi yang kuat, bertanggung jawab, sabar, kreatif, keinginan untuk belajar.<br />
<br />
Kandidat yang memenuhi syarat diminta untuk mengirimkan surat, resume / CV komprehensif, referensi, foto terbaru dan bukti kualifikasi untuk:<br />
Â Â Â Â Â Â Â Â Â Â Â Â Â Â Â Â Â Â Â  principal@jakartamontessori.com<br />
atau klik tombol di bawah ini<br />
<br />
<?php }
}
