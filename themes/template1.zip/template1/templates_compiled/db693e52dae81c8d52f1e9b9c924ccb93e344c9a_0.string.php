<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-03 09:33:06
  from 'db693e52dae81c8d52f1e9b9c924ccb93e344c9a' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f27d9d2243ec2_67490173',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f27d9d2243ec2_67490173 (Smarty_Internal_Template $_smarty_tpl) {
?>Mengajar dan mendidik siswa/i tingkat SD, dari jurusan yang linier. Membuat persiapan mengajar dan mendampingi siswa dalam kegiatan - kegiatan sekolah <?php }
}
