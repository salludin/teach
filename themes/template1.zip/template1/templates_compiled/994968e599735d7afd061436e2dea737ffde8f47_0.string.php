<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-09 01:38:26
  from '994968e599735d7afd061436e2dea737ffde8f47' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f2f5392a6ed07_61634625',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2f5392a6ed07_61634625 (Smarty_Internal_Template $_smarty_tpl) {
?>good proficiency in English<br />
loves children<br />
has critical thinking<br />
communicative<br />
collaborative<br />
creative<br />
computer & internet literate<?php }
}
