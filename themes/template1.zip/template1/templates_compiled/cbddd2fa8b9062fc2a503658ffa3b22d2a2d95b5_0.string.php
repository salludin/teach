<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-13 10:19:12
  from 'cbddd2fa8b9062fc2a503658ffa3b22d2a2d95b5' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f3513a00b7286_77034526',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f3513a00b7286_77034526 (Smarty_Internal_Template $_smarty_tpl) {
?>Job Description:<br />
-  Developing and implementing lesson plan<br />
-  Providing a safe and stimulating environment that facilitates learning<br />
-  Organising and supervising play and work activities (i.e: reading, cooking, music, dancing, etc)<br />
-  Liasing with parents/carers<br />
-  Monitoring, recording and reporting progress<br />
-  Organising school events<?php }
}
