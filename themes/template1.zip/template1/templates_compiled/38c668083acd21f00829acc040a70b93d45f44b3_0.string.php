<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-20 16:03:38
  from '38c668083acd21f00829acc040a70b93d45f44b3' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f3e9edab70c36_31606782',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f3e9edab70c36_31606782 (Smarty_Internal_Template $_smarty_tpl) {
?>D3 or any disipline teaching major.<?php }
}
