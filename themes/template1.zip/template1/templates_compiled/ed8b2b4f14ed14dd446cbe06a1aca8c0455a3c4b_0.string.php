<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-10 12:07:14
  from 'ed8b2b4f14ed14dd446cbe06a1aca8c0455a3c4b' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f313872030861_08934863',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f313872030861_08934863 (Smarty_Internal_Template $_smarty_tpl) {
?>- Educational Background: Bachelor in Library Science or Education Administration<br />
- Experience in teaching is a plus<br />
- Good English & interact well with children<br />
- Self regulated learning, organized, proficiency in ICT<?php }
}
