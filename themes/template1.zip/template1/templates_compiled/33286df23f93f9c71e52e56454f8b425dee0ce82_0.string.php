<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-01 11:28:04
  from '33286df23f93f9c71e52e56454f8b425dee0ce82' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f2551c4147327_99807635',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2551c4147327_99807635 (Smarty_Internal_Template $_smarty_tpl) {
?>Indonesian/expatriate, Male / female age 26 - 45 years old<br />
Good personality, Loves and cares about the world of education <br />
Physically and mentally healthy, no criminal history<br />
Honest, active, responsible and creative<br />
Ability to work individually and in a team<br />
Bachelor degree in Education according to each major, min. 4 years experience in teaching <br />
Can spare time for training<br />
Kindly send your resume, Curriculum Vitae and latest photograph to email admin@teachin.id to be our recommendation<br />
<?php }
}
