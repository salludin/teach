<?php
/* Smarty version 3.1.34-dev-7, created on 2020-07-30 08:15:26
  from 'e2da4bbf6c754eff2a8e41910dc0102ac057ce8e' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f22819e40ccf1_68818269',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f22819e40ccf1_68818269 (Smarty_Internal_Template $_smarty_tpl) {
?>1. Provide written evaluation report on studentsâ€™ progress based on the rubric to the principal.<br />
2. Meeting with parents during end of the terms and at any other time deemed to discuss studentsâ€™ progress.<br />
3. Involved in any event of the school.<br />
4. Preparing and submitting lessons plan, marks, and others administrative.<br />
5. Provide all materials needed for daily lessons.<br />
6. Deliver daily lessons in the class based on lessons plan that has been submitted.<br />
7. Provide assistance and guidance to students in need.<br />
<?php }
}
