<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-18 03:27:17
  from 'c2472d5bd01e9e29212d7a14eaa5a04b8fbb41b3' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f3b4a95c19027_87009508',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f3b4a95c19027_87009508 (Smarty_Internal_Template $_smarty_tpl) {
?>&bull;	Provide a lesson plan as preparation of teaching<br />
&bull;	Manage activities in class using early childhood education approach<br />
&bull;	Analyze and evaluate its teaching and learning activities<br />
&bull;	Rate, record and report student&#039;s development, progress and achievement, and ensure smooth communication to parents and Principal<br />
&bull;	Record student&#039;s attendance<br />
&bull;	Arrange assignments for a helper in class<br />
&bull;	Join and involved in the unit program as a committee <br />
&bull;	Others<br />
<?php }
}
