<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-11 15:24:52
  from '57b64de244e064518a6e794046eb97c4ab2d8de0' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f32b844278cd3_59823388',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f32b844278cd3_59823388 (Smarty_Internal_Template $_smarty_tpl) {
?>1. Tidak merokok<br />
2. diutamakan lulusan pesantren<br />
3. belum berkeluarga<?php }
}
