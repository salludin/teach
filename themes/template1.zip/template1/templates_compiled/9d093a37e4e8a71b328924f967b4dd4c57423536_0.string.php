<?php
/* Smarty version 3.1.34-dev-7, created on 2020-07-28 21:52:37
  from '9d093a37e4e8a71b328924f967b4dd4c57423536' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f209e250101e5_30424520',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f209e250101e5_30424520 (Smarty_Internal_Template $_smarty_tpl) {
?>Persyaratan Umum :<br />
â€¢Usia maks. 30 th<br />
â€¢Agama Kristen<br />
â€¢Rambut tidak dicat berwana mencolok, tidak memakai kutex, dan make up tidak berlebihan<?php }
}
