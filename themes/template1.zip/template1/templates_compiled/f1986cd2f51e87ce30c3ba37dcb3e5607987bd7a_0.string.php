<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-23 03:17:38
  from 'f1986cd2f51e87ce30c3ba37dcb3e5607987bd7a' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f41dfd2d5e236_98817112',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f41dfd2d5e236_98817112 (Smarty_Internal_Template $_smarty_tpl) {
?>â€¢	Manage marketing communication and activity campaign<br />
â€¢	Building and maintaining proactive relationship with local high school and universities<br />
<?php }
}
