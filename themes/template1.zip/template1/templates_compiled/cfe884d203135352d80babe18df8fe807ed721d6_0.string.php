<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-23 06:20:22
  from 'cfe884d203135352d80babe18df8fe807ed721d6' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f420aa67b8056_00709736',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f420aa67b8056_00709736 (Smarty_Internal_Template $_smarty_tpl) {
?>â€¢	Merencanakan, melaksanakan, dan mengevaluasi kegiatan pembelajaran <br />
â€¢	Melakukan proses administrasi dan  mendokumentasikan seluruh dokumen pembelajaran sesuai dengan ketentuan sekolah<br />
â€¢	Berkomunikasi dengan orang tua atau wali siswa untuk mengkomunikasikan kemajuan siswa dan menentukan kebutuhan yang menjadi prioritas bagi siswa dalam proses belajar <br />
â€¢	Melakukan koordinasi dan pertemuan-pertemuan dengan pihak-pihak sesuai kebutuhan dan ketentuan sekolah<br />
<?php }
}
