<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-05 06:53:04
  from '5e071745eddcdf0b2e7a88e6e65e338a23bfad9e' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f2a5750437b00_11365400',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2a5750437b00_11365400 (Smarty_Internal_Template $_smarty_tpl) {
?>Guru bimbel SMP dan SMA: Mengajar matematika, fisika, kimia.<br />
<br />
Beberapa lokasi penempatan yang dapat dipilih:<br />
Jelambar, Greenville (Jakarta Barat)<br />
Muara Karang (Jakarta Utara)<br />
<br />
Jam kerja:<br />
Full time: Weekday (14.00 - 21.00)<br />
Part time: 8 - 14 jam per minggu (weekdays only)<?php }
}
