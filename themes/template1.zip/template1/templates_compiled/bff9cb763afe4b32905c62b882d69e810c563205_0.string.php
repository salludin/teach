<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-22 03:26:09
  from 'bff9cb763afe4b32905c62b882d69e810c563205' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f4090510f6d49_91367199',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f4090510f6d49_91367199 (Smarty_Internal_Template $_smarty_tpl) {
?>â€¢	Planing, preparing and delivering SAT/Math lesson to classes<br />
â€¢	Assesing and continuously monitoring student progress<br />
â€¢	Providing personal feedback to student<br />
<?php }
}
