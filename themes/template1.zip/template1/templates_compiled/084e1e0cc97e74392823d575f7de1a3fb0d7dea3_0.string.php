<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-06 00:17:15
  from '084e1e0cc97e74392823d575f7de1a3fb0d7dea3' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f2b4c0b205d35_28062107',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2b4c0b205d35_28062107 (Smarty_Internal_Template $_smarty_tpl) {
?>Requirement :<br />
You have at least 1 year of teaching experience.<br />
The working hour is flexible within 2 â€“ 7 PM for Monday â€“ Friday and 8 AM â€“ 2 PM for Saturday.<br />
You are also allowed to choose the nearest Shinkenjuku branches to teach (Please kindly visit our website to check our existing branches location).<br />
<br />
You must be someone who are passionate in education, especially on math to apply for this position. And you also must be patient and enjoy interacting with children to enjoy being in this position.<br />
If you want to actively contribute to Indonesian educational improvement, come and join us in Shinkenjuku!<?php }
}
