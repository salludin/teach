<?php
/* Smarty version 3.1.34-dev-7, created on 2020-07-30 04:02:31
  from 'cd5b7f89c14fb7bed8741542df26f0807478cb19' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f2246571df1a2_03801305',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2246571df1a2_03801305 (Smarty_Internal_Template $_smarty_tpl) {
?>Merencanakan, melaksanakan, dan mengevaluasi kegiatan pembelajaran <br />
Melakukan proses administrasi dan  mendokumentasikan seluruh dokumen pembelajaran sesuai dengan ketentuan sekolah<br />
Berkomunikasi dengan orang tua atau wali siswa untuk mengkomunikasikan kemajuan siswa dan menentukan kebutuhan yang menjadi prioritas bagi siswa dalam proses belajar <br />
Melakukan koordinasi dan pertemuan-pertemuan dengan pihak-pihak sesuai kebutuhan dan ketentuan sekolah<br />
<?php }
}
