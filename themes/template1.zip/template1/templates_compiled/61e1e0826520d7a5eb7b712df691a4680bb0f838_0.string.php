<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-24 03:11:57
  from '61e1e0826520d7a5eb7b712df691a4680bb0f838' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f432ffd278bb1_72619237',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f432ffd278bb1_72619237 (Smarty_Internal_Template $_smarty_tpl) {
?>Be A Teacher & Make A Difference To Peopleâ€™s Life <br />
Briton International English School is an authorized centre of Cambridge Assessment English, part of the Cambridge University, UK, and the leading English language school outside Java & Bali with 20 centres all over Indonesia and with 3000 students every month.<br />
As we open more centres, we are now looking for self-motivated, professional look and fast learner characters to fill in our Full-time positions for; <br />
English Teacher for Papua<br />
Responsibilities;	<br />
â€¢	Prepare Lesson Plans<br />
â€¢	Teach English to Primary, Secondary & University students as well as professionals<br />
â€¢	Teach speaking & exam preparation classes<br />
â€¢	Attend Teacher Training & Professional Development Programs<br />
â€¢	Prepare & organize student extra activities<br />
<?php }
}
