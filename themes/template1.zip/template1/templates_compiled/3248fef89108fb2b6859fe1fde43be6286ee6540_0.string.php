<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-04 09:07:11
  from '3248fef89108fb2b6859fe1fde43be6286ee6540' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f29253f1143c2_13337626',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f29253f1143c2_13337626 (Smarty_Internal_Template $_smarty_tpl) {
?>&bull;	Having a desire to serve the Lord &amp; support MSCS vision and mission<br />
&bull;	Bachelor degree in the relevant field of study (preferebly Psychology/Education/English Literature)<br />
&bull;	English proficiency &amp; experience in similar field will be beneficial <br />
&bull;	Experience required minimum 1 year<br />
&bull;	Men or Woman at 22-40 years old<br />
&bull;	Honest, teamwork, good communication skills, open minded, resourceful, energetic<br />
&bull;	Will be based in Surabaya<br />
<?php }
}
