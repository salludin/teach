<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-11 11:21:32
  from 'a8c08cb1266b89481e720cc0af18debe0a195b4f' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f327f3c8d9ac0_03796445',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f327f3c8d9ac0_03796445 (Smarty_Internal_Template $_smarty_tpl) {
?>Kami membutuhkan beberapa tenanga pengajar bahasa asing di antaranya:<br />
- bahasa Inggris<br />
- bahasa Mandarin<br />
- bahasa Jepang<br />
- bahasa Korea<br />
- bahasa Perancis<br />
- bahasa Spanyol<br />
<?php }
}
