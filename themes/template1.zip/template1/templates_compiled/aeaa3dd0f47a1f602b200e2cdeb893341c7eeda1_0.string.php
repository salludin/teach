<?php
/* Smarty version 3.1.34-dev-7, created on 2020-07-29 00:07:17
  from 'aeaa3dd0f47a1f602b200e2cdeb893341c7eeda1' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f20bdb56c5f15_13158490',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f20bdb56c5f15_13158490 (Smarty_Internal_Template $_smarty_tpl) {
?>The Music teacher will be responsible for teaching Music to a variety of levels which may involve a mix of primary and junior/senior high school. This position is open for local or expat candidates.<?php }
}
