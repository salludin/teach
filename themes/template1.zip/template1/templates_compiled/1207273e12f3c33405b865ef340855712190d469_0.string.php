<?php
/* Smarty version 3.1.34-dev-7, created on 2020-07-28 21:52:37
  from '1207273e12f3c33405b865ef340855712190d469' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f209e25007c78_65586033',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f209e25007c78_65586033 (Smarty_Internal_Template $_smarty_tpl) {
?>Mengajar IELTS Foundation untuk siswa SMP dan SMA IPEKA<br />
<br />
(Penempatan IPEKA Pluit)<br />
â€¢Jumlah siswa : 29 orang<br />
â€¢Periode kontrak : November 2018 s.d Februari 2019 <br />
â€¢Jadwal : Kamis, pukul 13:15 â€“ 14:45 <br />
â€¢Lokasi : Sekolah IPEKA Pluit (Jl pluit timur Raya blok b no 1 penjaringan, Jakarta Utara)<br />
<br />
 (Penempatan IPEKA Grand Wisata Bekasi)<br />
â€¢ Jumlah siswa : 27 orang<br />
â€¢ Periode kontrak :  November 2018 s.d Februari 2019 <br />
â€¢Jadwal : Kamis, pukul 14:00-15.30<br />
â€¢Lokasi : Sekolah IPEKA Grand Wisata (Perumahan Grand Wisata, Jalan Sunset Avenue, Lambangsari, Tambun Selatan, Bekasi Jawa Barat 17510 <br />
<?php }
}
