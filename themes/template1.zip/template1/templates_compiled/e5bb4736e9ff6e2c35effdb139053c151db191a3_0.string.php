<?php
/* Smarty version 3.1.34-dev-7, created on 2020-07-29 17:52:27
  from 'e5bb4736e9ff6e2c35effdb139053c151db191a3' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f21b75b787621_07174115',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f21b75b787621_07174115 (Smarty_Internal_Template $_smarty_tpl) {
?>1.	Bachelor Degree from English Education <br />
2.	Excellent interpersonal communication skills<br />
3.	English speaker with strong command of the English<br />
4.	Responsible, discipline & creative. Planning, preparing and delivering lessons to students.<br />
<?php }
}
