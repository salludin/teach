<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-02 07:54:36
  from 'ac9590ea9e5e0185574a8bf6f8d2551d19de8c70' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f26713c75e259_07495183',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f26713c75e259_07495183 (Smarty_Internal_Template $_smarty_tpl) {
?>*Min D3 Degree <br />
*Love children<br />
*Fluent in English both oral & written <br />
*Minimum 1 year experience in teaching small children age 2-6 years old <br />
*Graduate form reputabale uiiversity <br />
*Maximum age 30 years old <br />
*Able to work in a team or individual<br />
*Able to play musical instrument will be advantaged <br />
*Willing to be located in Gading Serpong <br />
<br />
Only those who are shortlisted will be called for an interview Kindly send your CV attached with recent photo to : <br />
hrdpreschool@yahoo.com<?php }
}
