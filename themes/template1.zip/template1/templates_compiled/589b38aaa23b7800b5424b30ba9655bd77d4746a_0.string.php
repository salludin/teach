<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-05 10:02:23
  from '589b38aaa23b7800b5424b30ba9655bd77d4746a' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f2a83af036860_63697774',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2a83af036860_63697774 (Smarty_Internal_Template $_smarty_tpl) {
?>We are looking for Chemistry teachers for Senior High at IPEKA INTEGRATED Christian School - Meruya.<br />
<br />
Responsibilities :<br />
&bull;	Educate children in the light of the school vision and missions.<br />
&bull;	Assume full responsibility for all assigned tasks.<br />
<br />
<br />
<br />
<?php }
}
