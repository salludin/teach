<?php
/* Smarty version 3.1.34-dev-7, created on 2020-07-30 11:43:43
  from 'cf33918d08e0122ea5ef1dff267a0a7f26701540' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f22b26fc5b1d0_82021371',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f22b26fc5b1d0_82021371 (Smarty_Internal_Template $_smarty_tpl) {
?>*Love Children<br />
*Fluent in English both oral & written<br />
*Minimum 2 year experience in teaching small children age 2-6 year old<br />
*Graduate minimal S1 in Psycology Edication, English or English Literature , Early Childhood Education<br />
*Maximum age is 35 years old <br />
*Cheerful, patient, good teamwork, energetic, willing to learn new things<br />
*Able to play musical instrument will be advantaged<br />
*Willing to be located in Gading Serpong<br />
<br />
Only those who are shortlisted will be called for an interview Kindly send your CV attached with recent  photo to :<br />
hrdpreschool@yahoo.com<?php }
}
