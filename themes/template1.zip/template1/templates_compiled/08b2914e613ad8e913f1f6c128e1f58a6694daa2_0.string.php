<?php
/* Smarty version 3.1.34-dev-7, created on 2020-09-02 19:46:51
  from '08b2914e613ad8e913f1f6c128e1f58a6694daa2' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f4ff6ab7f7e52_45813426',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f4ff6ab7f7e52_45813426 (Smarty_Internal_Template $_smarty_tpl) {
?>Responsibilities:<br />
Tutoring Physics for Cambridge (IGCSE) and IB Curriculum,<br />
Preparing worksheets/materials before lessons,<br />
Monitoring students performance across each semester.<br />
<br />
Salary and Benefits:<br />
Starting salary 4 million IDR + commission depending on teaching hours.<br />
Based on tutors performances, LLC will send tutors to participate in Cambridge training/workshops to broaden their skills and knowledge on the Cambridge curriculum.<br />
<br />
Interested candidates, please send your complete resume to:<br />
<br />
JKT.LIGHTHOUSE.LC@gmail.com<?php }
}
