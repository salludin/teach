<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-10 07:39:06
  from 'dcf5e349f10fdec9d88300d77d5a448905ef7181' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f30f99ac80819_72627355',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f30f99ac80819_72627355 (Smarty_Internal_Template $_smarty_tpl) {
?>usia 27-35 tahun<br />
bachelor Degree, master degree mass communication/ marketing/ business<br />
fuent english<br />
minimal pengalaman 2 tahun sebagai staff admission di sekolah<?php }
}
