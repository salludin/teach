<?php
/* Smarty version 3.1.34-dev-7, created on 2020-07-30 05:03:38
  from 'cbfed2e5c4f1d0fcabfd2ed919b373054017cb37' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f2254aad3dc30_83856409',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2254aad3dc30_83856409 (Smarty_Internal_Template $_smarty_tpl) {
?>&bull;	Accompany class teacher in taking care of children in the class by following their direction <br />
&bull;	Helping class teacher in assisting children specifically and thoroughly such as accompanying children to the toilet, welcoming their arrival and accompanying in children&rsquo;s dismissal hours<br />
&bull;	Helping class teacher to supervise the development of children physically motoric and social emotional in daily teaching and learning activities<br />
&bull;	Others <br />
<?php }
}
