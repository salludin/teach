<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-20 16:13:41
  from 'ac6caee9bfa1d3467f1cc5bd77fb52838dc2a3a7' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f3ea135122d22_11620997',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f3ea135122d22_11620997 (Smarty_Internal_Template $_smarty_tpl) {
?>&bull;	Analyze the psychological test result.<br />
&bull;	Used to handle regular students as well as special needs students and capable of identifying/diagnose their condition to determine suitable therapy for them.<br />
&bull;	Do counseling and handling according to individual character.<br />
&bull;	Able and understand to make a concept and assessment of IEP as well as report that is related to special needs students&#039; development.<br />
&bull;	Can work together in teams.<br />
<br />
<br />
<?php }
}
