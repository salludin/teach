<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-20 16:13:41
  from '3721edcada4d44c698fc0b9724dea90d994bec4c' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f3ea13512dbf6_82295348',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f3ea13512dbf6_82295348 (Smarty_Internal_Template $_smarty_tpl) {
?>&bull;	Candidate must possess at least a master&rsquo;s degree in Psychology, especially in Clinical Child Psychology.<br />
&bull;	Have a valid SIPP (Surat Izin Praktek Psikologi) license. <br />
&bull;	Have at least five years of working experience as a Child Psychologist in especially in the education industry.<br />
&bull;	Used to handle regular students as well as special needs students.<br />
&bull;	Have a good understanding of the IEP concept for special needs students.<br />
&bull;	Have a good understanding of the personal character and how to overcome each character<br />
&bull;	Have good knowledge and skill to analyze and diagnose a psychological test report.<br />
&bull;	Capable of administrating psychological test tools and scoring.<br />
&bull;	Have excellent communication in English, both oral and written.<br />
&bull;	Proficient in MS. Office and internet.<br />
&bull;	Willing to work full time.<br />
<br />
Should you meet the qualifications, please send your updated CV with the application letter, update photographs, copy of identity card, academic degree, working certificate, and other related certificates to:  recruitment@icm.sch.id or hrd@icm.sch.id<?php }
}
