<?php
/* Smarty version 3.1.34-dev-7, created on 2020-07-28 14:18:32
  from 'bf47ea89e655e29e30950aa47fa85454eb6a3e49' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f2033b8b40fc0_20879727',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2033b8b40fc0_20879727 (Smarty_Internal_Template $_smarty_tpl) {
?>Chandra Kumala School is an inclusive school that promotes tolerance and team-work. Focusing on individuals strengths and weaknesses, we help discover and harness potential. Recognising the innate gifts in all our students, we provide individuals with a curriculum tailored to challenge and develop their intellectual, emotional, and social intelligence. <br />
The position of Principal is responsible for implementing our school mission and vision and for providing support for the instructional process. <?php }
}
