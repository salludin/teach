<?php
/* Smarty version 3.1.34-dev-7, created on 2020-07-30 08:15:26
  from 'f5b95a0eef6a3ce0c2159ae901e77127cc3fd3d0' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f22819e4154d7_52181233',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f22819e4154d7_52181233 (Smarty_Internal_Template $_smarty_tpl) {
?>1. Minimum Bachelor Degree<br />
2. Strong leadership, and good communication skill<br />
3. Able to work both individually and as part of a team.<br />
4. Have 2 years of experiences in the same field<br />
5. Good command in English and Mandarin (Written, Reading, and Speaking)<br />
6. Proficient at Microsoft Office application (Word, Excel, Power Point and etc.)<?php }
}
