<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-05 07:44:47
  from 'c8182e40a978f4cf01829a4195ab2e93806e0ab8' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f2a636f4aab50_86489604',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2a636f4aab50_86489604 (Smarty_Internal_Template $_smarty_tpl) {
?>Educational background / Professional certificate / Teaching certificate and or has a Master training in Physical Education.<br />
Experience in related field: 3 years teaching experience, preferably in national plus schools.<br />
Fluent both oral and written in Bahasa Indonesia and English (Min. TOEFL Score: 550 / IELTS: 6.5)<?php }
}
