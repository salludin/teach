<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-09 04:58:16
  from 'ac150f8ebd0516d3769f2c42f11b7ccb69a5ed68' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f2f8268cddf94_54148409',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2f8268cddf94_54148409 (Smarty_Internal_Template $_smarty_tpl) {
?>Menyiapkan pelajaran, mencatat absen murid, mengawasi siswa di dalam dan di luar kelas selama pelajaran berlangsung dan pada waktu istirahat dan pada waktu field trip, menerapkan peraturan sekolah, dll.<br />
<br />
<br />
<?php }
}
