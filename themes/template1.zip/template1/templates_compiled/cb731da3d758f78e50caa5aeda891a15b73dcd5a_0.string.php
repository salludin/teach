<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-21 03:25:23
  from 'cb731da3d758f78e50caa5aeda891a15b73dcd5a' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f3f3ea3dbddd4_93353591',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f3f3ea3dbddd4_93353591 (Smarty_Internal_Template $_smarty_tpl) {
?>- Bachelor in Business/Economy or finance management.<br />
- 5 years experience in related field.<br />
- Interested to unlock potential & benefits in education industry.<?php }
}
