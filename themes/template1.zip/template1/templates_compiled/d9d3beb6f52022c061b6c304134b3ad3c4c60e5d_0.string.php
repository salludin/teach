<?php
/* Smarty version 3.1.34-dev-7, created on 2020-07-30 05:03:38
  from 'd9d3beb6f52022c061b6c304134b3ad3c4c60e5d' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f2254aad46bd6_66457251',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2254aad46bd6_66457251 (Smarty_Internal_Template $_smarty_tpl) {
?>&bull;	Candidate must possess at least High School Degree. College student or Diploma Degree in Early Childhood Education Program or Montessori is more preferred<br />
&bull;	Having a working experience as a Teacher&rsquo;s Helper is more preferred<br />
&bull;	Capable of operating MS. Office (Word, Excel, Power Point, Publisher)<br />
&bull;	Proven self-initiative, creative and teamwork spirit with open-minded character<br />
&bull;	Possess strong Islamic characters<br />
&bull;	Able to communicate in English both oral and written<br />
&bull;	Ready to join in July 2020<br />
<br />
Should you meet the qualifications, please send your updated CV with the application letter, update photographs, copy of identity card, academic degree, working certificate, and other related certificates to:  recruitment@icm.sch.id or hrd@icm.sch.id<?php }
}
