<?php
/* Smarty version 3.1.34-dev-7, created on 2020-07-29 08:57:52
  from 'd393d4a55fd9cc3038b24f26286b66a18b7be38e' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f213a1097b4d7_98873513',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f213a1097b4d7_98873513 (Smarty_Internal_Template $_smarty_tpl) {
?>21 - 27 years old<br />
Excellent in English both oral and written<br />
Minimum Bachelor Degree from reputable university in any field<br />
Strong sales ability and capable of working under pressure<br />
Communicative, hard working, attractive and outgoing personality<br />
Strong passion in education field and dealing with people<br />
Placement : SUN Education Jakarta & Tangerang Branches<?php }
}
