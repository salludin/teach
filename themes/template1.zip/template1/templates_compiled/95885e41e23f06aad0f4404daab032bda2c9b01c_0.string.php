<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-20 12:53:34
  from '95885e41e23f06aad0f4404daab032bda2c9b01c' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f3e724ef1e305_02414516',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f3e724ef1e305_02414516 (Smarty_Internal_Template $_smarty_tpl) {
?>Required :<br />
<br />
&bull;	S1/S2 Bachelor&rsquo;s or Master&rsquo;s degree minimum in Art Education or related field<br />
&bull;	Excellent standard of English<br />
&bull;	Experience teaching Art in English at Primary or Secondary school level<br />
&bull;	Excellent communication skills and a positive and caring approach<br />
&bull;	Respect for diversity; religion, race, and gender<br />
&bull;	Experience with IB PYP (Primary Level)<br />
&bull;	Experience with IGCSE, or IBDP curriculum (Secondary level)<br />
&bull;	Willingness to take on an additional extracurricular duty or club<br />
<br />
Please send your CV and a recent photo to hrd@sekolahbogorraya.com We apologize, but only shortlisted candidates will be contacted.<br />
<?php }
}
