<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-09 00:35:17
  from 'a5cfa0cac5c9aa4eae77c6c20fbb50b52daa656b' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f2f44c5a46526_16493205',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2f44c5a46526_16493205 (Smarty_Internal_Template $_smarty_tpl) {
?>Menerima tamu dan menindaklanjutinya<br />
Menerima dan memproses pendaftaran siswa<br />
Pembuatan, sirkulasi dan dokumentasi surat keluar, note, pengumuman terkait kegiatan intern dan ekstern<br />
Bertindak sebagai kasir harian dan melakukan penutupan kas setiap hari kemudian membuat laporan harian kas<br />
Membuat data guru dan staf untuk dinas<br />
Mengelola pendaftaran ekskul dan mengelola kelancaran berjalannya program ekskul<br />
<?php }
}
