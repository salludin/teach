<?php
/* Smarty version 3.1.34-dev-7, created on 2020-07-29 02:36:41
  from 'b97c78aef081be73b3a178c9f162b312d950ce78' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f20e0b91d07e2_83804802',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f20e0b91d07e2_83804802 (Smarty_Internal_Template $_smarty_tpl) {
?>Lesson plan<br />
Class management<br />
Always update teaching skills<br />
<?php }
}
