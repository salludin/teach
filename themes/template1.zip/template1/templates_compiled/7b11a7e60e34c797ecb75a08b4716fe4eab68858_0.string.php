<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-23 06:20:29
  from '7b11a7e60e34c797ecb75a08b4716fe4eab68858' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f420aad66d178_55434017',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f420aad66d178_55434017 (Smarty_Internal_Template $_smarty_tpl) {
?>Holding Bachelor Degree in relation with Math with minimum GPA 2.80,<br />
Fluent in English with min TOEFL 500 or equivalent,<br />
Familiarity with the Cambridge IGCSE/A Levels/IB Diploma Curriculum is a plus,<br />
Fresh Graduates are welcome to apply.<?php }
}
