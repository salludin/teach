<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-01 01:56:51
  from '913a7e0eca48e6dd4017b3b65d8b40f97a58d5ac' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f24cbe3b89eb9_12362645',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f24cbe3b89eb9_12362645 (Smarty_Internal_Template $_smarty_tpl) {
?>&bull;	Having a desire to serve the Lord &amp; support MSCS vision and mission<br />
&bull;	Bachelor degree / higher in Psychology<br />
&bull;	Experience required minimum 1 year<br />
&bull;	Men or Woman at 22-40 years old<br />
&bull;	English proficiency &amp; experience in similiar field will be beneficial<br />
&bull;	Honest, teamwork, good communication skills, open minded, resourceful, energetic<br />
&bull;	Will be based in Surabaya<br />
<?php }
}
