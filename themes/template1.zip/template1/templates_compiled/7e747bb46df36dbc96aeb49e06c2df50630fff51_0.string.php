<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-03 00:05:41
  from '7e747bb46df36dbc96aeb49e06c2df50630fff51' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f2754d5483aa9_52428834',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2754d5483aa9_52428834 (Smarty_Internal_Template $_smarty_tpl) {
?>-Muslimah berusia maksimal 35 tahun<br />
-Pendidikan terakhir min. D3<br />
-Menguasai keterampilan komputer<br />
-Menguasai Bahasa Inggris (minimal pasif)<br />
-Memiliki kemampuan dan minat dalam administrasi perkantoran dan pengarsipan<br />
-Berdomisili di Bogor dan sekitarnya<br />
-Mengendarai sepeda motor (lebih disukai)<br />
-Berorientasi kerja dalam tim<br />
-Memiliki loyalitas yang baik<br />
-Diutamakan memiliki pengalaman yang sesuai (minimal 1 tahun)<?php }
}
