<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-03 21:53:53
  from 'cd51d105550abe4adb0682b709a3ae0c5146eee5' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f2887712ab6e8_63642353',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2887712ab6e8_63642353 (Smarty_Internal_Template $_smarty_tpl) {
?>S1/Bachelor Degree lulusan bahasa Mandarin<br />
Mempunyai sertifikat mengajar (lebih diutamakan)<br />
Berpengalaman min 1 tahun (lebih diutamakan)<br />
Bisa berkomunikasi dalam bahasa Inggris dengan baik dan lancar<br />
Bisa berinteraksi dengan anak-anak<br />
Bisa bekerjasama dengan baik<?php }
}
