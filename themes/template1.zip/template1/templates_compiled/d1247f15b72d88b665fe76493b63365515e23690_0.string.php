<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-12 18:29:24
  from 'd1247f15b72d88b665fe76493b63365515e23690' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f343504e5af60_98791375',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f343504e5af60_98791375 (Smarty_Internal_Template $_smarty_tpl) {
?>Recruiting staff for Institution, from Preschool to High School<br />
Previously worked in an International School<?php }
}
