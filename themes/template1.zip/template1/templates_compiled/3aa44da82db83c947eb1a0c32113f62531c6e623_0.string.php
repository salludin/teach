<?php
/* Smarty version 3.1.34-dev-7, created on 2020-07-31 05:04:09
  from '3aa44da82db83c947eb1a0c32113f62531c6e623' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f23a6490c6888_92931581',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f23a6490c6888_92931581 (Smarty_Internal_Template $_smarty_tpl) {
?>- 5 years experienced in sales and 2 years experiences in education industry<br />
-Interested to unlock potential in education industry<?php }
}
