<?php
/* Smarty version 3.1.34-dev-7, created on 2020-07-29 17:52:27
  from 'db0294f44f11b2f191c3df7a997dfd1c4cd3c933' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f21b75b760331_22754728',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f21b75b760331_22754728 (Smarty_Internal_Template $_smarty_tpl) {
?>1.	Checking on studentsâ€™ worksheet<br />
2.	Help students to improve their reading, writing and speaking skills<br />
3.	Implementing lesson plan, writing progress report and notes <br />
<?php }
}
