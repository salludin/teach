<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-09 01:38:26
  from '4da405aa4629cf7c988ad009e4e48e1fc186fb59' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f2f5392a65940_19652608',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2f5392a65940_19652608 (Smarty_Internal_Template $_smarty_tpl) {
?>Teaching Preschoolers (age from 1-6 years old)<br />
Collaborating with other teachers<br />
Preparing teaching materials<br />
Doing administration tasks, i.e. semestral reports, project report, lesson plans, and observation forms, etc.  <?php }
}
