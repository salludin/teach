<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-01 15:37:23
  from 'bd7ec0e0bbfe806bfdaf82d770e4b10f49820c54' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f258c33c83091_49154512',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f258c33c83091_49154512 (Smarty_Internal_Template $_smarty_tpl) {
?>&bull;	Having a desire to serve the Lord &amp; support MSCS Vision and Mission<br />
&bull;	Bachelor degree in the relevant field of study (preferebly Biology)<br />
&bull;	Experience required minimum 1 year<br />
&bull;	Men or Woman at 22-40 years old<br />
&bull;	English proficiency &amp; experience in simliar field will be beneficial<br />
&bull;	Honest, teamwork, good communication skills, open minded, resourceful, energetic<br />
&bull;	Will be based in Surabaya<br />
<?php }
}
