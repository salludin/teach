<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-05 07:21:27
  from '7a037ad84b4b26627c0ca799f84149afdb3982fa' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f2a5df7075935_42278537',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2a5df7075935_42278537 (Smarty_Internal_Template $_smarty_tpl) {
?>Enjoy working with children.<br />
Must have minimum Bachelor Degree in any fields.<br />
Fluent both oral and written in Bahasa Indonesia and English (Min. TOEFL Score: 550 / IELTS: 6.5)<br />
Must have minimum 3 years of hands on experience in teaching preschool, kindergarten, or primary level at National Plus or IB School<br />
Must have strong communication and presentation skills.<br />
Expert knowledge of child development and education.<?php }
}
