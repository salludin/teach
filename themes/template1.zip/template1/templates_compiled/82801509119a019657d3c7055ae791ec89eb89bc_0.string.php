<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-10 02:08:12
  from '82801509119a019657d3c7055ae791ec89eb89bc' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f30ac0c116bd7_14184059',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f30ac0c116bd7_14184059 (Smarty_Internal_Template $_smarty_tpl) {
?>Holding Bachelor Degree in relation with Physics with minimum GPA 2.80<br />
Fluent in English with min TOEFL 500 or equivalent<br />
Familiarity with the Cambridge IGCSE/A Levels/IB Diploma Curriculum is a plus<br />
Fresh Graduates are welcome to apply<?php }
}
