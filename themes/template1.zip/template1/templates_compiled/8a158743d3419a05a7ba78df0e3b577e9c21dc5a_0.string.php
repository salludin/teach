<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-11 12:00:10
  from '8a158743d3419a05a7ba78df0e3b577e9c21dc5a' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f32884a50df33_93614538',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f32884a50df33_93614538 (Smarty_Internal_Template $_smarty_tpl) {
?>Usia 22-35 tahun<br />
Sehat secara fisik dan mental<br />
S1 Bahasa Inggris <br />
Kreatif, kritis, inisiatif, kooperatif, dan dedikatif<br />
Terampil mengajar dan mengelola kelas<br />
Terampil mengoperasikan Ms. Office<br />
Mencintai dunia pendidikan<br />
Bersedia ditempatkan di Cengkareng Timur, Jakarta Barat<?php }
}
