<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-18 03:26:53
  from '8d261bc2b83b0d6b6a8f8ffee92169b998767866' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f3b4a7d343ff8_41288481',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f3b4a7d343ff8_41288481 (Smarty_Internal_Template $_smarty_tpl) {
?>- University Graduate<br />
<br />
- Able to speak and write Mandarin<br />
<br />
- Able to play and sing with children<br />
<br />
- Able to manage/handle class well<?php }
}
