<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-05 04:30:43
  from '884d5ea5aea686e3bc35d47fa832ac7220302a91' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f2a35f382ee31_29902659',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2a35f382ee31_29902659 (Smarty_Internal_Template $_smarty_tpl) {
?>Berkewarganegaraan Indonesia, minimal S1, kemampuan berbahasa Mandarin yang baik dan mampu bekerja dalam tim.<?php }
}
