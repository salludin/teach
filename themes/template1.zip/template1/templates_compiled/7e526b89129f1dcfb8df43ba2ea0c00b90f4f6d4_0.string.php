<?php
/* Smarty version 3.1.34-dev-7, created on 2020-07-30 00:35:06
  from '7e526b89129f1dcfb8df43ba2ea0c00b90f4f6d4' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f2215babda538_40464345',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2215babda538_40464345 (Smarty_Internal_Template $_smarty_tpl) {
?>1. Sarjana S1 bidang studi BHS Indonesia<br />
2. Berusia maksimal 30 tahun<br />
3. Belum menikah<br />
4. IPK 3.0<br />
5. Pengalaman 1 tahun<br />
6. Mempunyai keahlian komputer word, excel, Ms office<br />
7. mampu mengembangkan bahan ajar<?php }
}
