<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-03 21:53:53
  from '4842b7580f93f939e9c4a7636228cd55341aa8f2' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f2887712a3d86_51601750',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2887712a3d86_51601750 (Smarty_Internal_Template $_smarty_tpl) {
?>Menyusun perencanaan pembelajaran/planning<br />
Menyiapkan materi pembelajaran untuk kelas<br />
Menyusun materi pelajaran<br />
Membuat laporan pekembangan murid.<?php }
}
