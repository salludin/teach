<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-01 15:37:23
  from '14675ff42e8c05282473172d91e0bd79db256e03' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f258c33c7b038_90769065',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f258c33c7b038_90769065 (Smarty_Internal_Template $_smarty_tpl) {
?>&bull;	Prepare for teaching the subject of Biology (unit plan, assessment, project cover sheet, quiz, written test, handouts, assignments, etc)<br />
&bull;	Being able to understand &amp; constantly update the neeeds &amp; development of the students<br />
&bull;	Making analysis and evaluation of learning outcomes of the students<br />
<?php }
}
