<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-23 06:20:29
  from 'a9f470b4b7f2effad14ceacc9ac0c9f6b85b6a70' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f420aad663ce7_01981717',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f420aad663ce7_01981717 (Smarty_Internal_Template $_smarty_tpl) {
?>Tutoring Math for Cambridge (IGCSE) curriculum,<br />
Preparing worksheets/materials before lessons,<br />
Monitoring students performance across each semester.<br />
<?php }
}
