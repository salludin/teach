<?php
/* Smarty version 3.1.34-dev-7, created on 2020-07-29 00:07:17
  from 'ecd77941880ac44ddd4fe4907bf2a0152c9e1da7' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f20bdb56cde33_52153430',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f20bdb56cde33_52153430 (Smarty_Internal_Template $_smarty_tpl) {
?>-          S1/S2 Bachelorâ€™s or Masterâ€™s degree minimum in Music Education <br />
           or related field<br />
-          Excellent standard of English<br />
-          Experience teaching Music in English at high school level<br />
-          Excellent communication skills and a positive and caring approach<br />
-          Respect for diversity; religion, race, and gender<br />
-          Experience with IB PYP,IB Diploma, IGCSE, A Level or GAC <br />
           curricula<br />
-          Energy and Passion for Teaching and Learning<br />
-          A wide variety of music experience.<br />
<?php }
}
