<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-25 04:02:47
  from '02b4e6d345b783c97392eacde83bd9d334b68ebb' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f448d6716e611_52409292',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f448d6716e611_52409292 (Smarty_Internal_Template $_smarty_tpl) {
?>Candidate must possess minimal diploma degree with min. GPA 3.00 (scale 4,00)<br />
At least 1 year of working experience in the related field as marketing/ admission officer<br />
Able to do marketing design and web admin to maintain website are advantage<br />
Excellent in English<br />
Maximal age: 35 years old<br />
Pleasant and matured personality, communicative and highly adaptable to new challenges, responsible, moderate, creative, highly motivated, fast learner, and demonstrates initiative, good teamwork and customer oriented.<br />
Familiar with Microsoft Office and Internet<br />
<br />
If you feel that you can meet the qualification and up for the challenge, please send your complete resume and current color photograph by clicking button bellow<br />
<br />
<?php }
}
