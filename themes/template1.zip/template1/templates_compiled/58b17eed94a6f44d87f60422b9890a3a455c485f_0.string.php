<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-11 15:24:52
  from '58b17eed94a6f44d87f60422b9890a3a455c485f' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f32b8442660b2_22245205',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f32b8442660b2_22245205 (Smarty_Internal_Template $_smarty_tpl) {
?>â€¢   Berijazah minimal Sarjana (S1) sesuai bidang Studinya<br />
â€¢   Usia Maksinum 30tahun dan beium menikah<br />
â€¢   IPK minimal 3.30 (diutamakan PTN)<br />
â€¢   Sehat jasmani, rohani dan tidak merokok<br />
â€¢   Mempunyai pengalaman mengajar minimal 1 lahun<br />
â€¢   Mempunyai kemampuan komputer<br />
â€¢   Mampu mengembangkan bahan ajar, inovasi pembeiajaran<br />
â€¢   Lancar membaca Al Quran<br />
â€¢   Khusus untuk wali asrama putri berpengalaman di pesantren<br />
â€¢   Bersedia tinggal di Asrama<?php }
}
