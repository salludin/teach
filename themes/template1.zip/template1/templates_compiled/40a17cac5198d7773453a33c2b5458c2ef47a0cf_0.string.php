<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-12 18:29:24
  from '40a17cac5198d7773453a33c2b5458c2ef47a0cf' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f343504e63bf2_54083259',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f343504e63bf2_54083259 (Smarty_Internal_Template $_smarty_tpl) {
?>Is an Indonesian<br />
Speaks English well<br />
Holds a Bachelor degree in Law<br />
Has at least 5 years experiences in dealing HR matters<br />
Is familiar with Expatriate documentation	<br />
Is familiar with data reporting to Disnaker<br />
<br />
Kindly send your resume, Curriculum Vitae in English and recent photograph latest by 31st May, 2019 to: recruitment(at)montesiennaschool(dot)com<br />
<br />
Only shortlisted candidates will be notified.<?php }
}
