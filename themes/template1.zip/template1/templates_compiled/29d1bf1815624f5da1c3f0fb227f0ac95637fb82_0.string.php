<?php
/* Smarty version 3.1.34-dev-7, created on 2020-07-27 17:41:56
  from '29d1bf1815624f5da1c3f0fb227f0ac95637fb82' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f1f11e425c310_97205934',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f1f11e425c310_97205934 (Smarty_Internal_Template $_smarty_tpl) {
?>Maximal  40 years old<br />
Having a Bachelor in Physics or related science (fresh graduated are allowed) is preferred<br />
Familiar or experienced in Cambridge Curriculum is preferred<br />
Excellent communication skill in English (spoken & written), minimum with TOEFL score 550 are preferred<br />
Love physics and obsessed with teaching<br />
Responsible, creative, highly motivated, fast learner and demonstrates initiative, able to work in a team, has commitment and passion in teaching<br />
Pleasant and matured personality, communicative and highly adaptable to new challenges<br />
Good computer skill (word, excel and power point)<br />
Good communication skill<br />
Indonesian citizenship (not EXPAT teacher)<br />
"Only the selected candidates will be invited through e-mail/phone for Test and Interview"<br />
<br />
Qualified candidates are requested to submit a letter, comprehensive resume, references, a recent photograph and evidence of qualification to:<br />
<br />
Head of Human Resources<br />
Sekolah Pelangi Kasih<br />
Taman Grisenda Blok A1/28, Pantai Indah Timur<br />
Kapuk Muara, Jakarta Utara (14460)<br />
<br />
or clicking button bellow.<?php }
}
