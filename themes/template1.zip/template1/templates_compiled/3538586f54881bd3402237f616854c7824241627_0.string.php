<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-20 16:03:38
  from '3538586f54881bd3402237f616854c7824241627' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f3e9edab67980_08942979',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f3e9edab67980_08942979 (Smarty_Internal_Template $_smarty_tpl) {
?>1. To equip students with basic academic skills that are essential to future learning. <br />
2. Teach letter recognition, writing, and reading skills. <br />
<?php }
}
