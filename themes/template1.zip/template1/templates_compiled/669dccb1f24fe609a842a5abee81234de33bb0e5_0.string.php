<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-24 03:11:57
  from '669dccb1f24fe609a842a5abee81234de33bb0e5' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f432ffd282f34_06371226',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f432ffd282f34_06371226 (Smarty_Internal_Template $_smarty_tpl) {
?>Requirements;<br />
â€¢	A graduate from overseas is an advantage and is paid special allowance <br />
â€¢	Not more than 30 years old Indonesian <br />
â€¢	Professional look, energetic and a fast learner<br />
â€¢	Have min.500 ITP TOEFL or IELTS Overall Band 6.0 for a fresh graduate<br />
â€¢	Proficient in spoken English actively<br />
<?php }
}
