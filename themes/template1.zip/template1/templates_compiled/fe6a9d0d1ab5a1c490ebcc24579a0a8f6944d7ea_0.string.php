<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-01 02:11:26
  from 'fe6a9d0d1ab5a1c490ebcc24579a0a8f6944d7ea' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f24cf4ea582c9_90824909',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f24cf4ea582c9_90824909 (Smarty_Internal_Template $_smarty_tpl) {
?>â€¢	Merencanakan, melaksanakan, dan mengevaluasi kegiatan  pembelajaran <br />
â€¢	Melakukan proses administrasi dan  mendokumentasikan seluruh dokumen pembelajaran sesuai dengan ketentuan sekolah<br />
â€¢	Berkomunikasi dengan orang tua atau wali siswa untuk mengkomunikasikan kemajuan siswa dan menentukan kebutuhan yang menjadi prioritas bagi siswa dalam proses belajar <br />
â€¢	Melakukan koordinasi dan pertemuan-pertemuan dengan pihak-pihak sesuai kebutuhan dan ketentuan sekolah<br />
<?php }
}
