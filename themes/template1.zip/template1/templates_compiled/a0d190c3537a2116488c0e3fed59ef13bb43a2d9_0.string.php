<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-01 01:56:51
  from 'a0d190c3537a2116488c0e3fed59ef13bb43a2d9' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f24cbe3b759e0_22548410',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f24cbe3b759e0_22548410 (Smarty_Internal_Template $_smarty_tpl) {
?>&bull;	Setting up learning devices for children with special needs <br />
&bull;	Being able to understand &amp; constantly update the neeeds &amp; development of the students<br />
&bull;	Making analysis and evaluation of learning outcomes of the students<br />
<?php }
}
