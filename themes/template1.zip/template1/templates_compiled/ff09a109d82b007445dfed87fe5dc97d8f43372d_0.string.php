<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-06 13:10:58
  from 'ff09a109d82b007445dfed87fe5dc97d8f43372d' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f2c0162c3ef80_54385479',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2c0162c3ef80_54385479 (Smarty_Internal_Template $_smarty_tpl) {
?>- Min D3 degree<br />
<br />
- Having experience as an administrative staff in a school will be beneficial.<br />
<br />
- Highly motivated, hardworking, creative, communicative, team player and can do multi&ndash;function tasks.<?php }
}
