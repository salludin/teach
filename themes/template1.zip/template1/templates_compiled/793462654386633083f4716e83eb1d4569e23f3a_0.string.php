<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-13 18:27:05
  from '793462654386633083f4716e83eb1d4569e23f3a' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f3585f9cdf2b9_78205482',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f3585f9cdf2b9_78205482 (Smarty_Internal_Template $_smarty_tpl) {
?>Chandra Kumala School is inclusive school that promotes tolerance and team-work. Focusing on individuals strengths and weaknesses, we help discover and harness potential. Recognising the innate gifts in all our students, we provide individuals with a curriculum tailored to challenge and develop their intellectual, emotional, and social intelligence. <br />
The position of Art & Design Teacher is responsible to provide students with appropriate learning activities and experiences designed to fulfill their potential for intellectual, emotional, physical and social growth. <?php }
}
