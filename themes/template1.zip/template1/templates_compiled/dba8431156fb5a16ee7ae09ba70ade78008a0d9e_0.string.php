<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-23 03:17:29
  from 'dba8431156fb5a16ee7ae09ba70ade78008a0d9e' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f41dfc9363ca1_00126455',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f41dfc9363ca1_00126455 (Smarty_Internal_Template $_smarty_tpl) {
?>Bachelors Degree in English<br />
Teaching Certificate (PGCE or equivalent)<br />
or Bachelors of Education specialising in English<br />
Five Years of teaching experience<br />
Native Speaker of English <br />
High integrity, strong communication skills, patient, creative, responsible, willingness to learn.<br />
Qualified candidates are requested to submit a letter, comprehensive resume /CV, references, a recent photo and evidence of qualifications to principal@jakartamontessori.com<br />
or click on the button below.<?php }
}
