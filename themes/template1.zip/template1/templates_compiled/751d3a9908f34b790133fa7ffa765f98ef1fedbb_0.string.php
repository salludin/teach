<?php
/* Smarty version 3.1.34-dev-7, created on 2020-07-30 00:35:06
  from '751d3a9908f34b790133fa7ffa765f98ef1fedbb' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f2215babe20c2_99878035',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2215babe20c2_99878035 (Smarty_Internal_Template $_smarty_tpl) {
?>1. tidak merokok<br />
2. bersedia tinggal diasrama<br />
3. lancar membaca al quran<br />
4. sehat jasmani dan rohani<?php }
}
