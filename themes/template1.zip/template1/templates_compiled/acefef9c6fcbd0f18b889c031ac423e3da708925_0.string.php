<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-01 05:50:39
  from 'acefef9c6fcbd0f18b889c031ac423e3da708925' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f2502af6f45c2_30004064',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2502af6f45c2_30004064 (Smarty_Internal_Template $_smarty_tpl) {
?>Requirements :<br />
- Bachelor degree from any major<br />
- TOEFL min. 550<br />
- organized, perfect scheduling, neat & effecient with paperwork<br />
- Good in Math Basic<br />
<br />
send your complete documents ( ID Card, cover letter, updated resume,  bachelor certificate & its transcript, reference letter from previous work places, certificates) to recruitment@cahayabangsa.org<br />
<?php }
}
