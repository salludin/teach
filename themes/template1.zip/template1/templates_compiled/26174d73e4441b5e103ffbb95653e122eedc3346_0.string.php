<?php
/* Smarty version 3.1.34-dev-7, created on 2020-09-02 19:49:02
  from '26174d73e4441b5e103ffbb95653e122eedc3346' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f4ff72e1bb124_77291619',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f4ff72e1bb124_77291619 (Smarty_Internal_Template $_smarty_tpl) {
?>1.	Bachelor Degree from English Education <br />
2.	Excellent interpersonal communication skills<br />
3.	English speaker with strong command of the English<br />
4.	Responsible, discipline & creative. Planning, preparing and delivering lessons to students.<br />
5.	Love children<br />
<?php }
}
