<?php
/* Smarty version 3.1.34-dev-7, created on 2020-07-27 22:14:04
  from 'f759b669bc15e166e0f75f228a99c55f6d4ffa56' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f1f51ac4d33d6_75732555',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f1f51ac4d33d6_75732555 (Smarty_Internal_Template $_smarty_tpl) {
?>Melakukan rencana pembelajaran<br />
Menyediakan lembar kerja siswa yang sesuai dengan pembelajaran<br />
Mengembangkan kemampuan siswa secara holistik<br />
<br />
<?php }
}
