<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-04 19:18:34
  from 'a23ab0ea9e24a4a832f283020f022927ec589217' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f29b48aa41ce5_01125690',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f29b48aa41ce5_01125690 (Smarty_Internal_Template $_smarty_tpl) {
?>Usia 25-38 tahun<br />
Sehat secara fisik dan mental<br />
Pendidikan minimal S1 atau yang sederajat<br />
S1 Pendidikan Geografi/Ekonomi/Sejarah<br />
Memiliki pengalaman mengajar minimal 3 tahun<br />
Berbahasa Inggris aktif, sebagai bahasa pengantar<br />
Kreatif, kritis, inisiatif, kooperatif, dan dedikatif<br />
Terampil mengajar dan mengelola kelas<br />
Terampil mengoperasikan Ms. Office<br />
Mencintai dunia pendidikan<?php }
}
