<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-07 22:22:33
  from '6bbfce618b58ee7bc83f0cc6bc35f4dde8e4bed5' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f2dd42995e4f5_06979266',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2dd42995e4f5_06979266 (Smarty_Internal_Template $_smarty_tpl) {
?>â€¢	Candidate must possess at least a Bachelorâ€™s Degree (S1) from reputable university with minimum GPA 3.00.<br />
â€¢	Minimum 2 years of working experience in the related field.<br />
â€¢	Male / Female, 22-35 years old.<br />
â€¢	Have adequate KSAâ€™s (Knowledge, Skills, and Attitudes) followed by excellent classroom management skills to perform teaching activities (KBM).<br />
â€¢	Strong proficiency in English is a must (both spoken and written)<br />
â€¢	Mandarin speaker is an advantage<br />
â€¢	Have strong technology skills. Proficient in Microsoft Excel (emphasizing in student grades processing) and Microsoft Power Point (for presenting learning materials to students).<br />
â€¢	Have a great communication and people skills, writing skills, creativity, and patience.<br />
â€¢	Have passion and love in children.<br />
â€¢	Experienced in organizations / scouting (kepramukaan).<br />
â€¢	Our school has high expectations and employee must be prepared to run the extra mile and deliver beyond the call of duty.<br />
â€¢	Only qualified candidates are selected to proceed with the next stage of the selection process before the deadline (date of deadline).<br />
â€¢	Should you meet requirements:<br />
Please send create your CV completely and click â€œapplyâ€ to the Job via Online Media.<br />
â€¢	Documents required to attach: <br />
CV, Academic Transcript, Certificate of Academic (Ijazah), Certificate of Caremployment (Sertifikat pengalaman kerja), Identity Card (KTP and KK)<?php }
}
