<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-08 11:59:37
  from 'f643178a59223d1d84e9f0dc5c4d36267f4f1426' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f2e93a9ee81b6_38013038',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2e93a9ee81b6_38013038 (Smarty_Internal_Template $_smarty_tpl) {
?>S1 Teknologi informatika <br />
Berpengalaman min 1 tahun<br />
Bisa berinteraksi dalam bahasa Inggris dengan anak-anak<br />
Bisa bekerjasama dengan baik<br />
Mengerti tentang internet, jaringan, website, sosial media, programmer<?php }
}
