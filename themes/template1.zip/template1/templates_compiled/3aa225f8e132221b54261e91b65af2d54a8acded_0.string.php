<?php
/* Smarty version 3.1.34-dev-7, created on 2020-07-27 09:07:00
  from '3aa225f8e132221b54261e91b65af2d54a8acded' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f1e9934d4e593_52530695',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f1e9934d4e593_52530695 (Smarty_Internal_Template $_smarty_tpl) {
?>Minimal S1 pendidikan semua jurusan. (diutamakan pendidikan Bahasa Inggris & Pendidikan Bahasa Indonesia).<br />
Memiliki 1 tahun pengalaman bekerja sebagai Guru Sekolah Dasar.<br />
Mampu bekomunikasi menggunakan Bahasa Inggris baik dalam bentuk tulisan maupun lisan.<br />
Memiliki kepribadian yang sopan, baik dan ramah; personal maupun interpersonal.<br />
Terbiasa dalam mengoperasikan Aplikasi Office.<br />
Disiplin, bertanggung jawab, serta memiliki integritas yang tinggi.<br />
selalu memiliki keinginan untuk berkembang dalam bidang pendidikan.<br />
Menyukai dan mencintai anak-anak dan dunia pendidikan.<br />
Penempatan mengajar di Sekolah Dasar Budi Luhur Jl. Jombang Raya No. 77 Kota Tangerang Selatan, Banten.<br />
Lowongan bekerja untuk tahun pembelajaran 2019 - 2020<br />
<br />
<?php }
}
