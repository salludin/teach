<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-21 03:25:23
  from 'bc1075de956e0c8ae6c417f80657b1e0f12ca0f1' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f3f3ea3db4300_83768653',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f3f3ea3db4300_83768653 (Smarty_Internal_Template $_smarty_tpl) {
?>- Research prospective markets, pursue leads and follow through to a successful agreement.<br />
- Understand the target markets, including industry, company, project, company contacts and which market strategies can be used to attract clients.<br />
- Collaborate with marketing teams to ensure that requirements are met.<br />
- Possess a strong will understanding our products, our competetion in the industry and positioning.<?php }
}
