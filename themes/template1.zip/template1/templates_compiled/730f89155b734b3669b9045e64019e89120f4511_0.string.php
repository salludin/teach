<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-09 20:59:07
  from '730f89155b734b3669b9045e64019e89120f4511' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f30639bd38f35_51434620',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f30639bd38f35_51434620 (Smarty_Internal_Template $_smarty_tpl) {
?>All Level and All Subjects<?php }
}
