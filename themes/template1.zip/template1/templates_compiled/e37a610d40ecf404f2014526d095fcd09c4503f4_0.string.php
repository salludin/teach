<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-12 00:33:40
  from 'e37a610d40ecf404f2014526d095fcd09c4503f4' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f3338e41195e0_27120154',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f3338e41195e0_27120154 (Smarty_Internal_Template $_smarty_tpl) {
?>Karyawan tetap<br />
Punya pengalaman sebagai Supervisor lebih disukai<br />
Pendidikan Minimal S1<br />
Umur Maksimal 30 tahun<br />
Punya jiwa Leadership, suka kerja team<br />
Pintar dalam bernegosiasi dan Lobbying<br />
Fasilitas yang akan di dapat : Gaji tetap, Bonus penjualan, uang Transport, Uang pulsa, Uang sewa kendaraan, Uang kesehatan (BPJS dan Asuransi swasta)<br />
Bersedia bekerja di daerah kota dan kab Bekasi<?php }
}
