<?php
/* Smarty version 3.1.34-dev-7, created on 2020-07-27 15:15:09
  from 'c5bb7eb238d5c4fd54bd6dc8f2b799de03fefc67' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f1eef7d9f6c79_51532717',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f1eef7d9f6c79_51532717 (Smarty_Internal_Template $_smarty_tpl) {
?>Teaching, assessing, and evaluating students based on observation, assignments, and their attitudes<br />
Developing and working on the planner for teaching the materials<br />
Providing varied learning opportunities for students to help them develop their academic as well as their social behavior growth<br />
Meeting with parents and others that work or are related with the students to make sure the students develop at their best<br />
The total teaching hour is approximately 20 hours per week.<?php }
}
