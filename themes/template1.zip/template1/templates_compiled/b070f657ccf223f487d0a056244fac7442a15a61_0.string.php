<?php
/* Smarty version 3.1.34-dev-7, created on 2020-09-02 19:54:47
  from 'b070f657ccf223f487d0a056244fac7442a15a61' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f4ff8870066c2_21389438',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f4ff8870066c2_21389438 (Smarty_Internal_Template $_smarty_tpl) {
?>1.	Bachelor in PGSD/English/Math/Science<br />
2.	Man/Woman, max. 25 years old<br />
3.	Preferably fluent in english<br />
<?php }
}
