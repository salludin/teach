<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-05 09:05:34
  from '1542cfd54c4eb7ad906e1f963401a4362cf66896' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f2a765ee9c468_61312456',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2a765ee9c468_61312456 (Smarty_Internal_Template $_smarty_tpl) {
?>Indonesian/expatriate<br />
Male / female age 26 - 45 years old<br />
Good personality<br />
Loves and cares about the world of education <br />
Physically and mentally healthy<br />
Honest, active, responsible and creative<br />
Ability to work individually and in a team<br />
No criminal history<br />
<br />
Bachelor or Master degree holders according to each major<br />
Have a previous working experience min. 5 years (preferred)<br />
Proficient in speaking and writing in English<br />
Computer literate (Word, Excel & Power Point)<br />
<br />
Kindly send your resume, Curriculum Vitae in English and recent photograph latest by 17th May, 2019 / apply through our website: www(dot)fairview(dot)edu(dot)my	<br />
<br />
Only shortlisted candidates will be notified.<br />
<?php }
}
