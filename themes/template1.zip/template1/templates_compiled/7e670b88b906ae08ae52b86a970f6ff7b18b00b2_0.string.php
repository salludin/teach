<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-01 08:53:20
  from '7e670b88b906ae08ae52b86a970f6ff7b18b00b2' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f252d805700c4_16379000',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f252d805700c4_16379000 (Smarty_Internal_Template $_smarty_tpl) {
?>S1 lulusan jurusan agama Kristen/katholik<br />
Berpengalaman min 1 tahun<br />
Mempunyai sertifikat mengajar<br />
Bisa berinteraksi dengan anak-anak <br />
Bisa bekerjasama dengan baik<?php }
}
