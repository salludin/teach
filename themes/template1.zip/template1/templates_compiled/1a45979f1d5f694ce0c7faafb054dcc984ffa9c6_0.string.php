<?php
/* Smarty version 3.1.34-dev-7, created on 2020-07-29 20:38:08
  from '1a45979f1d5f694ce0c7faafb054dcc984ffa9c6' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f21de308a7c89_16581650',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f21de308a7c89_16581650 (Smarty_Internal_Template $_smarty_tpl) {
?>1.	Bachelor in Psychology/PAUD/English<br />
2.	Preferably woman, max. 25 years old<br />
3.	Love children and teaching<br />
4.	Preferably fluent in english<?php }
}
