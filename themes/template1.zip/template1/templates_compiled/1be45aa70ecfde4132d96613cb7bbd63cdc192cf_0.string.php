<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-05 23:29:45
  from '1be45aa70ecfde4132d96613cb7bbd63cdc192cf' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f2b40e9d8e627_00013437',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2b40e9d8e627_00013437 (Smarty_Internal_Template $_smarty_tpl) {
?>- Teaching History with a good approach and classroom management.<br />
<br />
- Submits the lesson plans, project plans, daily tests/quizzes on or before the agreed deadline.<br />
<br />
- Conducts yearly evaluation and revisions of the scheme of work.<br />
<br />
- Promotes the subject through co-curricular activities.<br />
<br />
- Attends relevant off-campus seminars and trainings.<?php }
}
