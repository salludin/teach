<?php
/* Smarty version 3.1.34-dev-7, created on 2020-07-29 00:05:26
  from '5183b898c7377561884b4ca94a97dba82259ce3c' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f20bd465a64c1_17639259',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f20bd465a64c1_17639259 (Smarty_Internal_Template $_smarty_tpl) {
?>The candidate must possess at least a Diploma in Education/Teaching/Training or equivalent.<br />
They must have at least 3 years of teaching experience in another educational setting, preferably a school.<br />
Teaching Assistants at Dyatmika School are expected to be punctual, professionally dressed in attire suitable for all classroom activities, community-minded and have good spoken and written English. They should respect the vision and mission of Dyatmika School. The Teaching Assistants should be flexible enough to carry out their duties and responsibilities in a variety of classes, ranging from EYP to Class 5.<?php }
}
