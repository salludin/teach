<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-02 22:34:29
  from 'fdb75a1f2cb2ed56d95dea58fb599bb984388488' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f273f75731115_86709957',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f273f75731115_86709957 (Smarty_Internal_Template $_smarty_tpl) {
?>General qualifications :<br />
Communicative, Collaborative, Innovative, Engaging, Adaptable Leader, Solution Oriented, Committed.<?php }
}
