<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-24 03:06:25
  from 'dc04526c2ef3e3832019b5f6d09d3f654ee52aa6' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f432eb1de9022_75274983',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f432eb1de9022_75274983 (Smarty_Internal_Template $_smarty_tpl) {
?>&bull;	Prepare for teaching the subject of English (unit plan, assessment, project cover sheet, quiz, written test, handouts, assignments, etc)<br />
&bull;	Being able to understand &amp; constantly update the neeeds &amp; development of the students<br />
&bull;	Making analysis and evaluation of learning outcomes of the students<br />
<?php }
}
