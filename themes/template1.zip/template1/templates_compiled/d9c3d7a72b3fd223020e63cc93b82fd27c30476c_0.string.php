<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-01 08:53:20
  from 'd9c3d7a72b3fd223020e63cc93b82fd27c30476c' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f252d805684b2_76095178',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f252d805684b2_76095178 (Smarty_Internal_Template $_smarty_tpl) {
?>Menyusun rencana pembelajaran<br />
Menyiapkan materi pelajaran<br />
Membuat laporan perkembangan murid<br />
<?php }
}
