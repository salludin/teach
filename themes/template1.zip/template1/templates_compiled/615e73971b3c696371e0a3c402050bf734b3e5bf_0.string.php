<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-22 03:26:09
  from '615e73971b3c696371e0a3c402050bf734b3e5bf' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f409051105f29_64366783',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f409051105f29_64366783 (Smarty_Internal_Template $_smarty_tpl) {
?>â€¢	Max. 30 years old<br />
â€¢	Bachelor degree in Mathematics  or relevant field of study, fresh graduates are welcome<br />
â€¢	Experience of teaching for 1 year<br />
â€¢	Proficient in English<br />
â€¢	Patient, knowledgeable, smart, creative, good attitude, discipline, hardworking<br />
<?php }
}
