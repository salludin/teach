<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-03 09:33:06
  from 'da856d87614fa29eb0b9503d31afd2e4626910c0' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f27d9d224bd34_39708227',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f27d9d224bd34_39708227 (Smarty_Internal_Template $_smarty_tpl) {
?>S 1 PGSD<?php }
}
