<?php
/* Smarty version 3.1.34-dev-7, created on 2020-07-31 08:49:59
  from '1d5b9d199e96e32a7bf329ec2ac3c45770184884' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f23db37c76138_12227240',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f23db37c76138_12227240 (Smarty_Internal_Template $_smarty_tpl) {
?>Persyaratan:<br />
1. Berusia max 27 tahun<br />
2. Memiliki skill dan pengalaman organisasi.<br />
3. Diutamakan memiliki pengalaman 1 tahun mengajar.<br />
4. Mampu mengajar menggunakan Bahasa Inggris aktif.<br />
5. Mampu menangani anak umur 2.5 sampai 15 tahun.<br />
6. Memahami Tajwid dan Tahsin.<br />
7. Memahami dasar-dasar agama dengan baik.<br />
8. Diutamakan lulusan Pesantren.<br />
9. Diutamakan Wanita<br />
10. Siap untuk terus belajar dan berkembang<br />
11. Tidak terdaftar dalam anggota organisasi yang dilarang pemerintah Republik Indonesia.<br />
12. Kuota terbatas.<br />
<br />
<?php }
}
