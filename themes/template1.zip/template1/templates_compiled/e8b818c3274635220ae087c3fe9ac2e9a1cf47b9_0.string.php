<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-06 13:10:58
  from 'e8b818c3274635220ae087c3fe9ac2e9a1cf47b9' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f2c0162c0edc9_41945976',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2c0162c0edc9_41945976 (Smarty_Internal_Template $_smarty_tpl) {
?>- Help the administrative task<br />
<br />
- Support other department when needed<?php }
}
