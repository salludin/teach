<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-10 21:43:00
  from 'c09fc3b29a639b9f624113582ef6d51646de8eeb' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f31bf64ad21e4_54383467',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f31bf64ad21e4_54383467 (Smarty_Internal_Template $_smarty_tpl) {
?>Usia maksimal 35 tahun<br />
Sarjana S1 (Matematika, Fisika, Kimia, Akuntansi, atau Teknik)<br />
Senang mengajar<br />
Mampu bekerjasama dalam team<br />
Fasilitas yang diberikan :<br />
<br />
Gaji pokok<br />
Tunjangan bulanan (kerajinan dan prestasi)<br />
Snack dan makan di kantor<br />
Tunjangan Hari Raya (THR)<br />
Asuransi kesehatan dan dana pensiun<?php }
}
