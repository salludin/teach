<?php
/* Smarty version 3.1.34-dev-7, created on 2020-07-27 16:00:24
  from 'c3595f4514550c00b67f61d62e1fbc767eb321f9' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f1efa180e6bf8_37728448',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f1efa180e6bf8_37728448 (Smarty_Internal_Template $_smarty_tpl) {
?>Supporting the Multimedia work in producing photos, video, banner, newsletter, etc.<?php }
}
