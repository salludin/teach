<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-08 05:53:05
  from 'd2815166d14b9cebd070e18f8f45a73aca5c775e' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f2e3dc15e2873_36396832',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2e3dc15e2873_36396832 (Smarty_Internal_Template $_smarty_tpl) {
?>1.	Bachelor Degree of Psychology<br />
2.	Preferably woman, max. 25 years old<br />
3.	Understand the psychological test tools<br />
4.	Good communication in English<br />
5.	Willing to travel for recruitment<?php }
}
