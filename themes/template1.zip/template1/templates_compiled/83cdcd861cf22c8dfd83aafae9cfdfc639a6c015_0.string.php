<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-12 17:32:36
  from '83cdcd861cf22c8dfd83aafae9cfdfc639a6c015' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f3427b4846ee8_79050503',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f3427b4846ee8_79050503 (Smarty_Internal_Template $_smarty_tpl) {
?>Max. 40 years old<br />
Having a Bachelor in Geography (fresh graduated are allowed) is preferred<br />
Familiar or experienced in Cambridge Curriculum is preferred<br />
Excellent communication skill in English (spoken & written), minimum with TOEFL score 550 are preferred<br />
Love geography and obsessed with teaching<br />
Responsible, creative, highly motivated, fast learner and demonstrates initiative, able to work in a team, has commitment and passion in teaching<br />
Pleasant and matured personality, communicative and highly adaptable to new challenges<br />
Good computer skill (word, excel and power point)<br />
Good communication skill<br />
Indonesian citizenship (not EXPAT teacher)<br />
"Only the selected candidates will be invited through e-mail/phone for Test and Interview".<br />
<br />
Qualified candidates are requested to submit a letter, comprehensive resume, references, a recent photograph and evidence of qualification to: <br />
<br />
Head of Human Resources<br />
<br />
Sekolah Pelangi Kasih<br />
<br />
Taman Grisenda Blok A1/28, Pantai Indah Timur<br />
<br />
Kapuk Muara, Jakarta Utara (14460)<br />
<br />
Or by clicking button bellow.<br />
<br />
<?php }
}
