<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-05 06:53:04
  from '216baba64f6a57453ec80f6995bb02f280a8447d' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f2a57504408b6_00043162',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2a57504408b6_00043162 (Smarty_Internal_Template $_smarty_tpl) {
?>Berkomitmen mengajar minimal 1 tahun.<br />
Jujur, bertanggung jawab, punya attitude dan sikap yang baik.<br />
Cepat belajar dan bersedia mengikuti training.<br />
MINIMAL mahasiswa /  sudah lulus SMA.<br />
Mampu mengajar matematika dan fisika (untuk tingkat SMP).<br />
Mampu mengajar matematika fisika dan kimia (untuk tingkat SMA).<?php }
}
