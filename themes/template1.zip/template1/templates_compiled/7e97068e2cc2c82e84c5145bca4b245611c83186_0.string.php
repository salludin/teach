<?php
/* Smarty version 3.1.34-dev-7, created on 2020-07-29 08:57:52
  from '7e97068e2cc2c82e84c5145bca4b245611c83186' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f213a109731a3_47368878',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f213a109731a3_47368878 (Smarty_Internal_Template $_smarty_tpl) {
?>Advise and assist students choosing the right institutions and destination<br />
Provide assistance and advice on accurate information in all aspect both educational and non-educational<br />
involved in promotions, campaign and special and special event activities<br />
Archieve student recruitment target (selling our services)<?php }
}
