<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-05 09:05:34
  from '92506624b586ca64f3b128892f200a43bce84fbd' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f2a765ee93c02_44514609',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2a765ee93c02_44514609 (Smarty_Internal_Template $_smarty_tpl) {
?>Extensive continuous professional development as an IB teacher<br />
Professional growth in a rapidly expanding network of schools<br />
<?php }
}
