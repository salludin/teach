<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-05 08:56:07
  from '6b534ed184f9965b253da982b5c177f7c595b7f4' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f2a74271eb2f9_04605747',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2a74271eb2f9_04605747 (Smarty_Internal_Template $_smarty_tpl) {
?>Is an Indonesian<br />
Speaks English well<br />
Holds a Master degree in Education<br />
Has previously been a principal of senior Secondary<br />
Has at least 10 years experiences in teaching<br />
Is familiar with data reporting to Diknas<br />
<br />
Good if has previously worked in an IB school<br />
Previously worked in an International School<br />
Familiar with IGCSE exams.<br />
Attended sertifikasi kepala sekolah<br />
<br />
Kindly send your resume, Curriculum Vitae and latest photograph latest by June, 17th, 2019 to this email address: recruitment@montesiennaschool.com	<br />
<br />
Only shortlisted candidates will be notified.<?php }
}
