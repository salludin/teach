<?php
/* Smarty version 3.1.34-dev-7, created on 2020-07-28 15:35:49
  from '8381d6b0837dda5b22678e981fae0c082012c1a1' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f2045d5195848_80563882',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2045d5195848_80563882 (Smarty_Internal_Template $_smarty_tpl) {
?>S.Pd in Geography / Economics / History<br />
<br />
Fresh Graduates welcome.<br />
<br />
Proficient in English<br />
<br />
High integrity, strong communication skills, patient, creative, responsible, willingness to learn.<br />
<br />
Indonesian Citizen (WNI)<br />
<br />
Qualified candidates are requested to submit a letter, comprehensive resume /CV, references, a recent photo and evidence of qualifications to:<br />
                    principal@jakartamontessori.com <br />
                    or click on the button below.<br />
<?php }
}
