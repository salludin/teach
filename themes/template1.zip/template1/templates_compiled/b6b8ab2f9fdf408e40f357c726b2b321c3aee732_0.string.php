<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-04 09:07:11
  from 'b6b8ab2f9fdf408e40f357c726b2b321c3aee732' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f29253f10c2f0_16685509',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f29253f10c2f0_16685509 (Smarty_Internal_Template $_smarty_tpl) {
?>&bull;	Ensure class discipline during learning activity in accordance to the daily routines and classroom rules introduced to the students<br />
&bull;	Give advice to students for improvement in learning and behavior<br />
&bull;	Lead students doing such even<br />
&bull;	Pay attention to students spiritual growth, being ready to be their advisor<br />
<?php }
}
