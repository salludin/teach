<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-07 12:20:09
  from 'd223a63561a4e2c62939bea20ed06f2e7ecc6754' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f2d46f97baaa5_42867480',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2d46f97baaa5_42867480 (Smarty_Internal_Template $_smarty_tpl) {
?>Maks. usia 30 tahun<br />
Min. Diploma Sistem Informasi/ Teknik Informatika<br />
Pengalaman 1 tahun diposisi yang sama<br />
Memiliki keterampilan Adobe Photoshop, Adobe Ilustrator, Flash, Dream Weaver, & Ms Office<br />
Menguasai HTML, database MySQL, & PHP<br />
Tekun, berorientasi pada hasil, dan dapat bekerja dengan deadline<br />
Project untuk 2 bulan (Januari - Februari)<?php }
}
