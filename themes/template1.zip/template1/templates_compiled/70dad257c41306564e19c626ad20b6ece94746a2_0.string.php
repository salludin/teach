<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-06 15:44:11
  from '70dad257c41306564e19c626ad20b6ece94746a2' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f2c254ba85239_73842795',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2c254ba85239_73842795 (Smarty_Internal_Template $_smarty_tpl) {
?>S1 jurusan bahasa inggris<br />
Memiliki kecintaan terhadap dunia anak dan pendidikan anak<br />
Fresh graduate/berpengalaman<br />
Usia maksimal 30 tahun<br />
<?php }
}
