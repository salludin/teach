<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-05 07:44:47
  from '243e7c2cac988a6f2eef6d90be6ef05bd63ddae5' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f2a636f4a2ab0_44145327',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2a636f4a2ab0_44145327 (Smarty_Internal_Template $_smarty_tpl) {
?>Teaching, assessing, and evaluating students based on observation, assignments, and their attitudes<br />
Providing varied learning opportunities for students to help them develop their academic as well as their social behavior growth<br />
Meeting with parents and others that work or are related with the students to make sure the students develop at their best<br />
The total teaching hour is approximately 20 hours per week.<?php }
}
