<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-05 14:48:26
  from 'e6bfd91c2edc6e3a89c516ffc1afd4c9bd2a1d3d' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f2ac6ba8e5db9_42939836',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2ac6ba8e5db9_42939836 (Smarty_Internal_Template $_smarty_tpl) {
?>S.Pd in Mathematics <br />
<br />
Fresh Graduates welcome.<br />
<br />
Proficient in English<br />
<br />
High integrity, strong communication skills, patient, creative, responsible, willingness to learn.<br />
<br />
Indonesian Citizen (WNI)<br />
<br />
Qualified candidates are requested to submit a letter, comprehensive resume /CV, references, a recent photo and evidence of qualifications to:<br />
                    principal@jakartamontessori.com <br />
                    or click on the button below.<br />
<?php }
}
