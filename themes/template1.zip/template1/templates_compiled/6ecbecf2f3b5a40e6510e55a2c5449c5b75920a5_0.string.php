<?php
/* Smarty version 3.1.34-dev-7, created on 2020-07-29 23:59:03
  from '6ecbecf2f3b5a40e6510e55a2c5449c5b75920a5' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f220d4787f905_02024334',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f220d4787f905_02024334 (Smarty_Internal_Template $_smarty_tpl) {
?>Advise and assist students in choosing the suitable English Program and provide accurate information in all aspects : the course programs, class schedules, tuition course<br />
Involved in promotions and special event activities such as companyâ€™s exhibition, education fair or school expo<br />
Making monthly report<?php }
}
