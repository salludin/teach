<?php
/* Smarty version 3.1.34-dev-7, created on 2020-07-30 02:17:11
  from 'd05709748d8630841461a6ac6130c0ea24d3cacf' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f222da7f34067_54394801',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f222da7f34067_54394801 (Smarty_Internal_Template $_smarty_tpl) {
?>- Maintain the content of JMS Social Media<br />
- Maintain the content of JMS Website<br />
- Create design for all promotion material<br />
- In charge of the School Annual Year Book from creating concept, design, content and printing to publisher<br />
- Marketing and promotion duties to promote the school<br />
- Handling of the student admission process<?php }
}
