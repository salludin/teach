<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-01 02:11:26
  from 'ecce20bdd56f5a8b47869da313084f7896ee65da' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f24cf4ea60421_62661778',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f24cf4ea60421_62661778 (Smarty_Internal_Template $_smarty_tpl) {
?>â€¢	S1 semua jurusan (pendidikan dan non pendidikan)<br />
â€¢	Memiliki kecintaan terhadap dunia anak dan pendidikan anak<br />
â€¢	Fresh graduate/berpengalaman<br />
â€¢	Usia maksimal 30 tahun<br />
<?php }
}
