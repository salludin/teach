<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-02 11:41:00
  from 'ba504d148500fd988a736dc9631e48a9c7518954' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f26a64c1330b4_09067600',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f26a64c1330b4_09067600 (Smarty_Internal_Template $_smarty_tpl) {
?>Male or Female <br />
Teaching qualification and certification in science (Bachelor Degree) <br />
Science teaching experience <br />
Fluent in English <br />
Committed to excellence in educating, nurturing and providing safe environment for students<?php }
}
