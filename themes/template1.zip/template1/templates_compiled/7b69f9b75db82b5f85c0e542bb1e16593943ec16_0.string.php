<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-09 22:16:25
  from '7b69f9b75db82b5f85c0e542bb1e16593943ec16' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f3075b9a1ac19_31376955',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f3075b9a1ac19_31376955 (Smarty_Internal_Template $_smarty_tpl) {
?>Guru Bimbel SMA (1 kelas 5 siswa)<br />
Bidang Studi: Bhs. Indonesia, Bhs. Inggris, Geografi, Sejarah, Ekonomi, Kimia, Biologi, Matematika (IPA-IPS), & Fisika<br />
<br />
Gaji 4 juta/bulan belum termasuk Bonus dan Tunjangan-tunjangan. Menerima Full Time dan Part Time.<br />
<br />
Penempatan: JABODETABEK + Bandung & Semarang <?php }
}
