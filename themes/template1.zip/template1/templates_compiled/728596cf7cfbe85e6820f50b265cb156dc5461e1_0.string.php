<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-11 11:21:32
  from '728596cf7cfbe85e6820f50b265cb156dc5461e1' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f327f3c8e2e79_64113423',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f327f3c8e2e79_64113423 (Smarty_Internal_Template $_smarty_tpl) {
?>S1 di jurusan yang berkaitan, namun kita bisa pertimbangkan jika tidak berkaitan, selama kemampuan bahasa asing tersebut bagus, baik lisan maupun tulisan. Resume dapat dikirim ke infinityserpong@yahoo.com. Terima kasih. <?php }
}
