<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-11 10:53:04
  from 'd6eeb33a1063f92da6ac9cd392b847bf0c17570c' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f327890b5be25_52832354',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f327890b5be25_52832354 (Smarty_Internal_Template $_smarty_tpl) {
?>â€¢   Berijazah minimal Sarjana (S1) sesuai bidang Studinya<br />
â€¢   Usia Maksinum 30 tahun<br />
â€¢   IPK minimal 3.30 (diutamakan PTN)<br />
â€¢   Sehat jasmani, rohani dan tidak merokok<br />
â€¢   Mempunyai pengalaman mengajar minimal 1 lahun<br />
â€¢   Mempunyai kemampuan komputer<br />
â€¢   Mampu mengembangkan bahan ajar, inovasi pembeiajaran<br />
â€¢   Lancar membaca Al Quran<br />
â€¢   Bersedia tinggal diasrama<?php }
}
