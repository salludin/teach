<?php
/* Smarty version 3.1.34-dev-7, created on 2020-07-27 21:32:49
  from '8fab0444d2806cb859fe9c239aa376d8ac5c9c95' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f1f4801f38901_22178183',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f1f4801f38901_22178183 (Smarty_Internal_Template $_smarty_tpl) {
?>&bull;	Prepare for teaching the subject of Social (Unit Plan, Assessments, Project Cover Sheet, Quiz, Written Test, Handouts, Assignments, etc)<br />
&bull;	Being able to understand and constantly update the needs and development of the students <br />
&bull;	Making analysis and evaluation of learning outcomes of the students <br />
<?php }
}
