<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-24 03:07:08
  from 'c8e82f1917a0a5e2818706fab5a11ee551197b27' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f432edc4cf020_57957606',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f432edc4cf020_57957606 (Smarty_Internal_Template $_smarty_tpl) {
?>- Degree in Social Science or Humanities preferred<br />
- Two or more years of teaching experience preferred<br />
- Broad knowledge of Indonesia<br />
- Min. TOEFL score 450 from LIA, ETS, or IELTS score 5<br />
- Excellent communication and people skills<br />
<?php }
}
