<?php
/* Smarty version 3.1.34-dev-7, created on 2020-07-27 08:47:34
  from '4ddc032c4deee44dbc7a2af69c4315b2d6e2d8a4' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f1e94a6be0bd0_77773134',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f1e94a6be0bd0_77773134 (Smarty_Internal_Template $_smarty_tpl) {
?>Lesson plan<br />
Class management<br />
Always update teaching skills<br />
Computer literature and Proficiency in English<?php }
}
