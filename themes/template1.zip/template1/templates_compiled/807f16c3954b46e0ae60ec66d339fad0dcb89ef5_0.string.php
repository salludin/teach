<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-10 12:07:13
  from '807f16c3954b46e0ae60ec66d339fad0dcb89ef5' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f313872001018_66298858',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f313872001018_66298858 (Smarty_Internal_Template $_smarty_tpl) {
?>A librarian handles most of the aspects of library work such as ordering, processing materials, overseeing the budget, supervising student helpers and library clerical staff.<br />
Librarian teaches students how to access, evaluate, and use the appropriate information, such as navigating the internet to find relevant information quickly.<br />
<?php }
}
