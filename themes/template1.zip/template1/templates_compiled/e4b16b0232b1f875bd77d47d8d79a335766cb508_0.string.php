<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-15 14:30:48
  from 'e4b16b0232b1f875bd77d47d8d79a335766cb508' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f37f1980ece64_72330213',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f37f1980ece64_72330213 (Smarty_Internal_Template $_smarty_tpl) {
?>Dibutuhkan Guru Matematika dan Fisika SMP yang akan ditempatkan di Pusat Bimbingan Belajar di Jakarta.<br />
Fasilitas yang diberikan :<br />
1. Gaji pokok<br />
2. Tunjangan bulanan (kerajinan dan prestasi)<br />
3. Snack dan makan di kantor<br />
4. Tunjangan Hari Raya (THR)<br />
5. Asuransi kesehatan dan dana pensiun<?php }
}
