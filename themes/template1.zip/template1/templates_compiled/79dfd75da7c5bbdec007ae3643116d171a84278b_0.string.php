<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-05 10:02:23
  from '79dfd75da7c5bbdec007ae3643116d171a84278b' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f2a83af03eba3_50796466',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2a83af03eba3_50796466 (Smarty_Internal_Template $_smarty_tpl) {
?>Qualifications :<br />
&bull;	Bachelor&rsquo;s Degree in Chemistry or equivalent<br />
&bull;	Excellent in Chemistry (oral and written)<br />
&bull;	Passionate in teaching children<br />
&bull;	Maximum of 40 years old<br />
&bull;	Responsible, creative, highly motivated, and a fast-learner<br />
&bull;	Pleasant and matured personality, communicative and highly adaptable to new challenges, initiative and able to work in a team<br />
&bull;	Good communication skills<br />
&bull;	Good computer skills (such as Word, Excel and Power Point)<br />
&bull;	Familiar with or have previous experience(s) in International Baccalaureate (IB) Curriculum (preferred)<br />
<br />
Send your CV to: recruitment@ipeka.org<br />
or Registern online to: www.ipeka.org/karier<br />
<?php }
}
