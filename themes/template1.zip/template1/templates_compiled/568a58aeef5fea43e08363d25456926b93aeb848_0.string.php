<?php
/* Smarty version 3.1.34-dev-7, created on 2020-07-30 23:23:52
  from '568a58aeef5fea43e08363d25456926b93aeb848' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f23568880e441_60101384',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f23568880e441_60101384 (Smarty_Internal_Template $_smarty_tpl) {
?>Male/Female, 25-40 years old<br />
INTERNATIONAL Teachers are welcome<br />
Bachelor degree or higher from a reputable university with related subject<br />
Teaching experience with similar subject field will be beneficial<br />
Familiar with Cambridge curriculum and IB Development Program<br />
English proficiency is a must, both written and spoken<br />
Advance leadership, teamwork, good communication skills and highly motivated<br />
Able to get along well with people regardless of their ethnicity, religion & social status<br />
Honest, open minded, resourceful, energetic & supporting the school vision of character, faith and wisdom<br />
Location : Surabaya<?php }
}
