<?php
/* Smarty version 3.1.34-dev-7, created on 2020-07-27 03:56:08
  from '/home/u6574599/public_html/content/themes/default/images/svg/sunrise.svg' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f1e50588785d1_76183165',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1b0f919fec2f4f715bedd1cef4cd14f03f3e1117' => 
    array (
      0 => '/home/u6574599/public_html/content/themes/default/images/svg/sunrise.svg',
      1 => 1589561315,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f1e50588785d1_76183165 (Smarty_Internal_Template $_smarty_tpl) {
echo '<?xml ';?>
version="1.0" encoding="iso-8859-1"<?php echo '?>';?>

<!-- Generator: Adobe Illustrator 19.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 512 512" style="enable-background:new 0 0 512 512;" xml:space="preserve">
<path style="fill:#FFA92F;" d="M375.302,378.565c5.824-14.858,8.878-30.837,8.878-46.87c0-70.68-57.5-128.18-128.18-128.18
	s-128.18,57.5-128.18,128.18c0,16.033,3.054,32.012,8.878,46.87H375.302z"/>
<rect x="241" y="113.56" style="fill:#FFE63F;" width="30" height="60"/>
<g>
	
		<rect x="335.118" y="138.797" transform="matrix(-0.8658 -0.5003 0.5003 -0.8658 568.8095 490.1171)" style="fill:#FFCE00;" width="29.999" height="59.997"/>
	
		<rect x="403.982" y="207.746" transform="matrix(-0.4993 -0.8664 0.8664 -0.4993 422.1974 719.469)" style="fill:#FFCE00;" width="29.999" height="59.997"/>
	
		<rect x="414.121" y="316.923" transform="matrix(-1 -0.0012 0.0012 -1 887.8428 664.3786)" style="fill:#FFCE00;" width="60" height="30"/>
</g>
<g>
	
		<rect x="130.994" y="153.8" transform="matrix(-0.5003 -0.8658 0.8658 -0.5003 95.3877 392.6473)" style="fill:#FFE63F;" width="59.997" height="29.999"/>
	
		<rect x="62.129" y="222.753" transform="matrix(-0.8664 -0.4993 0.4993 -0.8664 53.2372 489.7469)" style="fill:#FFE63F;" width="59.998" height="29.998"/>
	
		<rect x="52" y="301.918" transform="matrix(-0.0012 -1 1 -0.0012 -264.8372 399.3169)" style="fill:#FFE63F;" width="30" height="60"/>
</g>
<path style="fill:#FF8A1D;" d="M375.302,378.565c5.824-14.858,8.878-30.837,8.878-46.87c0-70.68-57.5-128.18-128.18-128.18v175.05
	H375.302z"/>
<rect x="256" y="113.56" style="fill:#FFCE00;" width="15" height="60"/>
<rect y="368.44" style="fill:#E57500;" width="512" height="30"/>
<rect x="256" y="368.44" style="fill:#994C00;" width="256" height="30"/>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
</svg>
<?php }
}
