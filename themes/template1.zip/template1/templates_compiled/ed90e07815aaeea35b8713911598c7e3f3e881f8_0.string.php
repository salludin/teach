<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-07 15:52:51
  from 'ed90e07815aaeea35b8713911598c7e3f3e881f8' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f2d78d3cc7468_39799809',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f2d78d3cc7468_39799809 (Smarty_Internal_Template $_smarty_tpl) {
?>Briton International English School is an authorized centre of Cambridge Assessment English, part of the Cambridge University, UK, and the leading English language school outside Java & Bali with 20 centres all over Indonesia and with 3000 students every month.<br />
As we open more centres, we are now looking for self-motivated, professional look and fast learner characters to fill in our Full-time positions for; <br />
English Teacher for Manado<br />
Responsibilities;	<br />
â€¢	Prepare Lesson Plans<br />
â€¢	Teach English to Primary, Secondary & University students as well as professionals<br />
â€¢	Teach speaking & exam preparation classes<br />
â€¢	Attend Teacher Training & Professional Development Programs<br />
â€¢	Prepare & organize student extra activities<br />
<?php }
}
