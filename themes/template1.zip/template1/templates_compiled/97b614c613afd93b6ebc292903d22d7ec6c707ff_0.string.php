<?php
/* Smarty version 3.1.34-dev-7, created on 2020-08-09 14:56:13
  from '97b614c613afd93b6ebc292903d22d7ec6c707ff' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f300e8dbb7817_70872248',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f300e8dbb7817_70872248 (Smarty_Internal_Template $_smarty_tpl) {
?>Female<br />
Max. 35 years old<br />
Hold minimum of D3<br />
Fresh graduate are welcome<br />
Fluency in english, written and spoken<br />
Good personality, willing to learn, creative<br />
Team player and Self-motivated<?php }
}
