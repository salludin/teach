<?php
/* Smarty version 3.1.34-dev-7, created on 2020-07-31 07:35:12
  from 'd58389389f83d8508c36f6aaed1a6fb5db0dc20a' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5f23c9b062f027_84856523',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5f23c9b062f027_84856523 (Smarty_Internal_Template $_smarty_tpl) {
?>Menyampaikan bahan ajar ke siswa<br />
Mengelola kelas<br />
Menjalin relasi yang baik dengan siswa<br />
Menyusun Program Tahunan, Program Semester, Silabus, dan Rencana Pengajaran<br />
Menilai proses dan hasil belajar siswa serta membuat laporan penilaian<br />
Membantu Kepala Sekolah dalam tugas-tugas tertentu<br />
Mendukung segala hal untuk mencapai Visi dan Misi Sekolah<?php }
}
